CREATE DATABASE eSHOP
GO

USE [eSHOP]
GO

/****** Object:  Table [dbo].[BILL]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BILL](
	[BILLID] [bigint] IDENTITY(1000001,1) NOT NULL,
	[CUSTID] [bigint] NULL,
	[ORDID] [bigint] NULL,
	[SHIPID] [bigint] NULL,
	[ADDRESSLINE1] [varchar](200) NULL,
	[ADDRESSLINE2] [varchar](200) NULL,
	[CITY] [varchar](100) NULL,
	[STATE] [varchar](40) NULL,
	[ZIPCODE] [varchar](20) NULL,
	[PHONE] [varchar](20) NULL,
	[NEWGUIDID] [uniqueidentifier] NULL,
 CONSTRAINT [PK_BILL] PRIMARY KEY CLUSTERED 
(
	[BILLID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[BRAND]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BRAND](
	[BRANDID] [bigint] IDENTITY(1,1) NOT NULL,
	[BRAND] [varchar](250) NULL,
	[STAMP] [datetime] NULL CONSTRAINT [DF_BRAND_STAMP]  DEFAULT (getdate()),
 CONSTRAINT [PK_BRAND] PRIMARY KEY CLUSTERED 
(
	[BRANDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[CART]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CART](
	[CARTID] [bigint] IDENTITY(1,100000001) NOT NULL,
	[CUSTID] [bigint] NULL,
	[INVENTORYID] [bigint] NULL,
	[QUANTITY] [bigint] NULL,
	[ORDID] [bigint] NULL,
	[STAMP] [datetime] NULL,
 CONSTRAINT [PK_CART] PRIMARY KEY CLUSTERED 
(
	[CARTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[CATEGORY]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[CATEGORY](
	[CATID] [bigint] IDENTITY(1,1) NOT NULL,
	[CATEGORY] [varchar](250) NOT NULL,
	[STAMP] [datetime] NULL CONSTRAINT [DF_CATEGORY_STAMP]  DEFAULT (getdate()),
	[SHOWCATEGORYMENU] [bit] NULL CONSTRAINT [DF_CATEGORY_FRONTPAGECATEGORY]  DEFAULT ((1)),
	[SHOWCATEGORYTAB] [bit] NULL CONSTRAINT [DF_CATEGORY_CATEGORYTAB]  DEFAULT ((1)),
 CONSTRAINT [PK_CATEGORY] PRIMARY KEY CLUSTERED 
(
	[CATID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[CATEGORYBRAND]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CATEGORYBRAND](
	[CATBRANDID] [bigint] IDENTITY(1,1) NOT NULL,
	[CATID] [bigint] NULL,
	[BRANDID] [bigint] NULL,
	[STAMP] [datetime] NULL CONSTRAINT [DF_CATEGORYBRAND_STAMP]  DEFAULT (getdate()),
 CONSTRAINT [PK_CATEGORYBRAND] PRIMARY KEY CLUSTERED 
(
	[CATBRANDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[CUSTOMER]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[CUSTOMER](
	[CUSTID] [bigint] IDENTITY(1000000,1) NOT NULL,
	[FIRSTNAME] [varchar](70) NULL,
	[LASTNAME] [varchar](70) NULL,
	[DISPLAYNAME] [varchar](250) NULL,
	[STAMP] [datetime] NULL,
	[CUSTGUIDID] [uniqueidentifier] NULL,
	[USERNAME] [nvarchar](350) NULL,
	[PASSWORD] [nvarchar](350) NULL,
 CONSTRAINT [PK_CUSTOMER] PRIMARY KEY CLUSTERED 
(
	[CUSTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UQ_CUSTGUIDID] UNIQUE NONCLUSTERED 
(
	[CUSTGUIDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[ERROR]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ERROR](
	[ERRORID] [bigint] IDENTITY(1,1) NOT NULL,
	[ASPNET] [bit] NULL,
	[AJAX] [bit] NULL,
	[SQLSERVER] [bit] NULL,
	[ERRORMSG] [nvarchar](3500) NULL,
	[PAGE] [nvarchar](250) NULL,
	[METHOD] [nvarchar](250) NULL,
	[PROCEDURENAME] [nvarchar](250) NULL,
 CONSTRAINT [PK_ERROR] PRIMARY KEY CLUSTERED 
(
	[ERRORID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[IMAGE]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IMAGE](
	[IMAGEID] [bigint] IDENTITY(1,1) NOT NULL,
	[URL] [nvarchar](400) NULL,
	[IMAGEDATA] [varbinary](max) NULL,
	[MAIN] [bit] NULL CONSTRAINT [DF_IMAGE_MAIN]  DEFAULT ((0)),
	[STAMP] [datetime] NULL CONSTRAINT [DF_IMAGE_STAMP]  DEFAULT (getdate()),
	[INVENTORYGUIDID] [uniqueidentifier] NULL,
	[IMAGEGUIDID] [uniqueidentifier] NULL CONSTRAINT [DF_IMAGE_IMAGEGUIDID]  DEFAULT (newid()),
 CONSTRAINT [PK_IMAGE] PRIMARY KEY CLUSTERED 
(
	[IMAGEID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[INVENTORY]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INVENTORY](
	[INVENTORYID] [bigint] IDENTITY(100001,1) NOT NULL,
	[BRANDID] [bigint] NOT NULL,
	[CATID] [bigint] NOT NULL,
	[PRODUCTNAME] [nvarchar](250) NULL,
	[DESCRIPTION] [nvarchar](3500) NULL,
	[YEAR] [nvarchar](10) NULL,
	[COLOR] [nvarchar](150) NULL,
	[SIZE] [nvarchar](150) NULL,
	[LOGONID] [bigint] NOT NULL,
	[QUANTITY] [bigint] NOT NULL CONSTRAINT [DF_INVENTORY_QUANTITY]  DEFAULT ((0)),
	[NEW] [bit] NOT NULL CONSTRAINT [DF_INVENTORY_NEW]  DEFAULT ((0)),
	[USED] [bit] NOT NULL CONSTRAINT [DF_INVENTORY_USED]  DEFAULT ((0)),
	[PRICE] [decimal](19, 2) NOT NULL,
	[STAMP] [datetime] NULL CONSTRAINT [DF_INVENTORY_STAMP]  DEFAULT (getdate()),
	[DISPLAY] [bit] NOT NULL CONSTRAINT [DF_INVENTORY_DISPLAY]  DEFAULT ((0)),
	[INVENTORYGUIDID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_INVENTORY_INVENTORYGUIDID]  DEFAULT (newid()),
	[RECOMMENDITEM] [bit] NULL CONSTRAINT [DF_INVENTORY_RECOMMENDITEM]  DEFAULT ((0)),
 CONSTRAINT [PK_INVENTORY] PRIMARY KEY CLUSTERED 
(
	[INVENTORYID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UQ_INVENTORYGUIDID] UNIQUE NONCLUSTERED 
(
	[INVENTORYGUIDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[LOGONPRODUPLOAD]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LOGONPRODUPLOAD](
	[LOGONID] [int] IDENTITY(1,1) NOT NULL,
	[USERNAME] [nvarchar](150) NULL,
	[PASSWORD] [nvarchar](150) NULL,
	[OWNER] [nvarchar](300) NULL,
	[STAMP] [datetime] NULL,
 CONSTRAINT [PK_LOGONPRODUPLOAD] PRIMARY KEY CLUSTERED 
(
	[LOGONID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[ORDER]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ORDER](
	[ORDID] [bigint] IDENTITY(10835283,1) NOT NULL,
	[CUSTID] [bigint] NULL,
	[PROCESSED] [bit] NULL,
	[STAMP] [datetime] NULL,
 CONSTRAINT [PK_ORDER] PRIMARY KEY CLUSTERED 
(
	[ORDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[PRODUCTRELATE]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PRODUCTRELATE](
	[PRODRELATEID] [bigint] IDENTITY(1,1) NOT NULL,
	[STAMP] [datetime] NOT NULL,
	[INVENTORYID] [bigint] NULL,
 CONSTRAINT [PK_PRODUCTRELATE] PRIMARY KEY CLUSTERED 
(
	[PRODRELATEID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[SHIP]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SHIP](
	[SHIPID] [bigint] IDENTITY(10000001,1) NOT NULL,
	[CUSTID] [bigint] NULL,
	[ORDID] [bigint] NULL,
	[BILLID] [bigint] NULL,
	[ADDRESSLINE1] [nvarchar](200) NULL,
	[ADDRESSLINE2] [nvarchar](200) NULL,
	[CITY] [nvarchar](100) NULL,
	[STATE] [nvarchar](40) NULL,
	[ZIPCODE] [nvarchar](20) NULL,
	[PHONE] [nvarchar](20) NULL,
	[TRACKNUMBER] [nvarchar](200) NULL,
	[SHIPGUID] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SHIP] PRIMARY KEY CLUSTERED 
(
	[SHIPID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[SYSTEM]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SYSTEM](
	[SYSTEMID] [int] IDENTITY(1,1) NOT NULL,
	[SHOWMENU] [bit] NULL,
	[SHOWCATEGORYTAB] [bit] NULL,
	[SHOWNEWUSED] [bit] NULL CONSTRAINT [DF_SYSTEM_SHOWNEWUSED]  DEFAULT ((0)),
 CONSTRAINT [PK_SYSTEM] PRIMARY KEY CLUSTERED 
(
	[SYSTEMID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[VIDEO]    Script Date: 11/16/2017 12:55:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VIDEO](
	[VIDEOID] [bigint] IDENTITY(1,1) NOT NULL,
	[URL] [nvarchar](3500) NULL,
	[YOUTUBE] [bit] NOT NULL CONSTRAINT [DF_VIDEO_YOUTUBE]  DEFAULT ((0)),
	[INVENTORYGUIDID] [uniqueidentifier] NULL,
 CONSTRAINT [PK_VIDEO] PRIMARY KEY CLUSTERED 
(
	[VIDEOID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[BILL] ADD  CONSTRAINT [DF_BILL_NEWGUIDID]  DEFAULT (newid()) FOR [NEWGUIDID]
GO

ALTER TABLE [dbo].[CART] ADD  CONSTRAINT [DF_CART_QUANTITY]  DEFAULT ((0)) FOR [QUANTITY]
GO

ALTER TABLE [dbo].[CART] ADD  CONSTRAINT [DF_CART_STAMP]  DEFAULT (getdate()) FOR [STAMP]
GO

ALTER TABLE [dbo].[CUSTOMER] ADD  CONSTRAINT [DF_CUSTOMER_STAMP]  DEFAULT (getdate()) FOR [STAMP]
GO

ALTER TABLE [dbo].[CUSTOMER] ADD  CONSTRAINT [DF_CUSTOMER_GUIDID]  DEFAULT (newid()) FOR [CUSTGUIDID]
GO

ALTER TABLE [dbo].[ERROR] ADD  CONSTRAINT [DF_ERROR_ASPNET]  DEFAULT ((0)) FOR [ASPNET]
GO

ALTER TABLE [dbo].[ERROR] ADD  CONSTRAINT [DF_ERROR_AJAX]  DEFAULT ((0)) FOR [AJAX]
GO

ALTER TABLE [dbo].[ERROR] ADD  CONSTRAINT [DF_ERROR_SQLSERVER]  DEFAULT ((0)) FOR [SQLSERVER]
GO

ALTER TABLE [dbo].[ORDER] ADD  CONSTRAINT [DF_ORDER_STAMP]  DEFAULT (getdate()) FOR [STAMP]
GO

ALTER TABLE [dbo].[PRODUCTRELATE] ADD  CONSTRAINT [DF_PRODUCTRELATE_STAMP]  DEFAULT (getdate()) FOR [STAMP]
GO

ALTER TABLE [dbo].[SHIP] ADD  CONSTRAINT [DF_SHIP_SHIPGUID]  DEFAULT (newid()) FOR [SHIPGUID]
GO


USE [eSHOP]
GO

/****** Object:  StoredProcedure [dbo].[SP_BRAND]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO


USE [eSHOP]
GO

/****** Object:  View [dbo].[VU_SINGLEIMAGE]    Script Date: 11/16/2017 12:57:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[VU_SINGLEIMAGE] AS
SELECT * FROM IMAGE 
WHERE main = 1




GO

/****** Object:  View [dbo].[VU_CART]    Script Date: 11/16/2017 12:57:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[VU_CART] AS
SELECT i.inventoryid, i.price, c.quantity, p.year, p.product, p.prodid, si.url, c.ordid, c.custid, i.quantity as inventoryqty, s.size
FROM cart c LEFT JOIN inventory i ON i.inventoryid = c.inventoryid
LEFT JOIN product p ON i.prodid = p.prodid
LEFT JOIN size s ON i.sizeid = s.sizeid
LEFT JOIN VU_SINGLEIMAGE si ON i.inventoryid = si.inventoryid




GO

/****** Object:  View [dbo].[vu_IMAGE]    Script Date: 11/16/2017 12:57:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vu_IMAGE] AS
SELECT *
FROM IMAGES0101.[dbo].[IMAGE]
GO

/****** Object:  View [dbo].[VU_INVENTORY]    Script Date: 11/16/2017 12:57:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[VU_INVENTORY] AS
SELECT p.product, p.description, p.year, i.inventoryid, g.url, g.imageid, c.color, s.size, cc.displayname, --NEEDED VALUES
i.brandid, i.prodid, i.custid, i.sizeid, i.colorid, i.quantity, i.new, i.used, i.price, i.catid, g.main --EXTRA VALUES
FROM inventory i INNER JOIN product p ON i.prodid = p.prodid --1 to 1
INNER JOIN image g ON i.inventoryid = g.inventoryid  --1 to MANY
INNER JOIN color c ON i.colorid = c.colorid --1 TO 1
INNER JOIN size s ON s.sizeid = i.sizeid -- 1 TO 1
INNER JOIN customer cc ON i.custid = cc.custid
WHERE i.quantity <> 0




GO







	
CREATE PROC [dbo].[SP_BRAND]
AS
SELECT brandid, brand
FROM brand 
ORDER BY brand ASC





GO

/****** Object:  StoredProcedure [dbo].[SP_BRANDCOUNT]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[SP_BRANDCOUNT]
AS
SELECT b.brandid, b.brand, (COUNT(b.brand)) AS brandtotal
INTO #temp
FROM brand b INNER JOIN inventory i ON b.brandid = i.brandid
WHERE i.quantity <> 0
GROUP BY b.brandid, b.brand

SELECT b.brandid, b.brand, ISNULL(t.brandtotal, 0) as brandtotal
FROM brand b LEFT OUTER JOIN #temp t ON b.brandid = t.brandid
WHERE ISNULL(t.brandtotal, 0) > 0
ORDER BY b.brand ASC

DROP TABLE #temp
GO

/****** Object:  StoredProcedure [dbo].[SP_CATEGORY]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[SP_CATEGORY]
AS
SELECT catid, category 
FROM CATEGORY
ORDER BY category
GO

/****** Object:  StoredProcedure [dbo].[SP_CATEGORY_BRAND]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_CATEGORY_BRAND]
AS
--OLD VERSION
--SELECT c.catid, b.brandid, c.category, b.brand
--FROM categorybrand cb LEFT JOIN BRAND b ON cb.brandid = b.brandid
--LEFT JOIN category c ON cb.catid = c.catid

--NEW VERSION - NOW FILTER OUT 0 QUANTITY - NOT SURE IF THIS WILL HAVE BUGS
SELECT c.catid, b.brandid, c.category, b.brand
FROM categorybrand cb LEFT JOIN BRAND b ON cb.brandid = b.brandid
LEFT JOIN category c ON cb.catid = c.catid
INNER JOIN inventory i ON cb.catid = i.catid AND cb.brandid = i.brandid
WHERE i.quantity <> 0
GROUP BY c.catid, b.brandid, c.category, b.brand
GO

/****** Object:  StoredProcedure [dbo].[SP_CATEGORYMENU]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_CATEGORYMENU]
AS
SELECT catid, category, showcategorymenu, showcategorytab
FROM category
GO

/****** Object:  StoredProcedure [dbo].[SP_CUSTCART]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_CUSTCART]
@biCUSTID BIGINT
AS
SELECT * FROM VU_CART
WHERE custid = @biCUSTID AND ordid IS NULL




GO

/****** Object:  StoredProcedure [dbo].[SP_CUSTOMER]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_CUSTOMER]
AS
SELECT * 
FROM customer



GO

/****** Object:  StoredProcedure [dbo].[SP_DELETEBRAND]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_DELETEBRAND]
@biBRANDID BIGINT,
@biCATID BIGINT
AS
DECLARE @bALREADYEXIST BIT = 1
IF (SELECT COUNT(inventoryid) FROM inventory WHERE brandid = @biBRANDID AND catid = @biCATID) = 0
BEGIN
	DELETE FROM categorybrand WHERE brandid = @biBRANDID AND catid = @biCATID
	IF (SELECT COUNT(catbrandid) FROM categorybrand WHERE brandid = @biBRANDID) = 0
	BEGIN
		DELETE FROM brand
		WHERE brandid = @biBRANDID
	END
	SET @bALREADYEXIST = 0
END
SELECT brand, brandid
FROM brand
ORDER BY brand

SELECT @bALREADYEXIST AS ALREADYEXIST
GO

/****** Object:  StoredProcedure [dbo].[SP_DELETECARTITEM]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[SP_DELETECARTITEM]
@biCUSTID BIGINT,
@biINVENTORYID BIGINT
AS
DELETE FROM cart
WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL

SELECT FORMAT(SUM(quantity * price),'C', 'en-us') AS SUBTOTAL, @biINVENTORYID as inventoryid
FROM VU_CART WHERE custid = @biCUSTID AND ordid IS NULL




GO

/****** Object:  StoredProcedure [dbo].[SP_DELETECATEGORY]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_DELETECATEGORY]
@biCATID BIGINT
AS
DECLARE @bALREADYEXIST BIT = 1
IF (SELECT COUNT(inventoryid) FROM inventory WHERE catid = @biCATID) = 0
BEGIN
	DELETE FROM category
	WHERE catid = @biCATID

	DELETE FROM brand WHERE brandid IN (
	SELECT brandid	FROM categorybrand
	WHERE catid = @biCATID
	AND brandid NOT IN (SELECT brandid FROM categorybrand WHERE catid <> @biCATID))
	--need a list of category not being used

	DELETE FROM categorybrand 
	WHERE catid = @biCATID

	SET @bALREADYEXIST = 0
END
SELECT brandid, brand
FROM brand

SELECT catid, category
FROM category
ORDER BY category

SELECT @bALREADYEXIST AS ALREADYEXIST
GO

/****** Object:  StoredProcedure [dbo].[SP_DELETEIMAGE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_DELETEIMAGE]
@biINVENTORYID BIGINT,
@vURL VARCHAR(400)
AS
DELETE FROM image
WHERE url = @vURL AND inventoryid = @biINVENTORYID

IF (SELECT COUNT(imageid) FROM image WHERE inventoryid = @biINVENTORYID AND main = 1) = 0
BEGIN --UPDATE FIRST IMAGE AS MAIN IMAGE iNCASE YOu DELETE MAIN IMAGE
	UPDATE image
	SET main = 1
	WHERE inventoryid = @biINVENTORYID AND imageid = (SELECT MIN(imageid) FROM image WHERE inventoryid = @biINVENTORYID)
END

SELECT imageid, url, prodid, inventoryid, main
FROM image
WHERE inventoryid = @biINVENTORYID



GO

/****** Object:  StoredProcedure [dbo].[SP_DELETEPRODUCTRELATE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_DELETEPRODUCTRELATE]
@biCUSTID BIGINT,
@biPRODRELATEID BIGINT,
@biINVENTORYID BIGINT
AS
DECLARE @biMAINPRODID BIGINT
SET @biMAINPRODID = (SELECT prodid FROM inventory WHERE inventoryid = @biINVENTORYID)

DELETE FROM productrelate 
WHERE prodrelateid = @biPRODRELATEID

--FILL TEMP TABLE WITH NEW UNIQUE PRODUCT RELATE
SELECT v.product as relateproduct,  v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
INTO #temp
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.new = 1
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID

ALTER TABLE #TEMP ADD PRIMARY KEY CLUSTERED 
(	PRODRELATEID ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--FIND MISSING UNIQUE USED PRODUCT NOT FILLED BY NEW UNIQUE PRODUCT
INSERT INTO #temp (relateproduct, relatedescription, relateyear, relateurl, PRODRELATEID)
SELECT v.product as relateproduct, v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.used = 1 --multiple used product !! WARNING YOU NEED TO GET ONLY 1 USED PRODUCT!!
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID
ORDER BY relateurl DESC

SELECT * FROM #temp



GO

/****** Object:  StoredProcedure [dbo].[SP_DELETEVIDEO]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_DELETEVIDEO]
@uiINVENTORYGUIDID UNIQUEIDENTIFIER,
@biVIDEOID BIGINT
AS
DELETE FROM video 
WHERE videoid = @biVIDEOID

SELECT videoid, url, inventoryguidid, youtube 
FROM video 
WHERE inventoryguidid = @uiINVENTORYGUIDID 
GO

/****** Object:  StoredProcedure [dbo].[SP_DISPLAYPRODUCT]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_DISPLAYPRODUCT]
@biINVENTORYID BIGINT,
@bDisplay BIT
AS
UPDATE inventory
SET display = @bDisplay
WHERE inventoryid = @biINVENTORYID



GO

/****** Object:  StoredProcedure [dbo].[SP_FIRSTMAINIMAGEID]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_FIRSTMAINIMAGEID]
@biMAINIMAGEID BIGINT
AS
UPDATE image
SET main = 1
WHERE imageid = @biMAINIMAGEID




GO

/****** Object:  StoredProcedure [dbo].[SP_GETPRODSIZECOLORCATBRANDID]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_GETPRODSIZECOLORCATBRANDID]
@biINVENTORYID BIGINT
AS
SELECT i.prodid, i.sizeid, i.colorid, i.catid, i.brandid, c.catbrandid
FROM inventory i INNER JOIN categorybrand c ON (i.catid = c.catid AND i.brandid = c.brandid)
WHERE inventoryid = @biINVENTORYID




GO

/****** Object:  StoredProcedure [dbo].[SP_IMAGEBYID]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_IMAGEBYID]
@uiIMAGEGUIDID UNIQUEIDENTIFIER
AS
SELECT imagedata
FROM image
WHERE imageguidid = @uiIMAGEGUIDID
GO

/****** Object:  StoredProcedure [dbo].[SP_IMAGEBYINV]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_IMAGEBYINV]
@uiINVENTORYGUIDID UNIQUEIDENTIFIER = NULL,
@biINVENTORYID BIGINT = NULL
AS
IF @uiINVENTORYGUIDID IS NOT NULL
BEGIN
	SELECT imageid, imageguidid
	FROM image
	WHERE inventoryguidid = @uiINVENTORYGUIDID
END
ELSE IF @biINVENTORYID IS NOT NULL
BEGIN
	SELECT @uiINVENTORYGUIDID = inventoryguidid
	FROM inventory
	WHERE inventoryid = @biINVENTORYID

	SELECT imageid, imageguidid
	FROM image
	WHERE inventoryguidid = @uiINVENTORYGUIDID
END
GO

/****** Object:  StoredProcedure [dbo].[SP_IMAGEGUIDID]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_IMAGEGUIDID]
(@uiIMAGEGUIDID UNIQUEIDENTIFIER)
AS
SELECT imagedata
FROM image
WHERE imageguidid = @uiIMAGEGUIDID
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTBRAND]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTBRAND]
@vBRAND VARCHAR(250),
@biCATID BIGINT
AS
DECLARE @biBRANDID BIGINT
IF (SELECT COUNT(brandid) FROM brand WHERE brand = @vBRAND) = 0
BEGIN
	INSERT INTO brand (brand)
	VALUES (@vBRAND)
	SET @biBRANDID = SCOPE_IDENTITY()
END
ELSE
BEGIN
	SET @biBRANDID = (SELECT brandid FROM brand WHERE brand = @vBRAND)
END
IF (SELECT COUNT(catbrandid) FROM categorybrand WHERE catid = @biCATID AND brandid = @biBRANDID) = 0
BEGIN
	INSERT INTO categorybrand (catid, brandid)
	VALUES (@biCATID, @biBRANDID)
END

SELECT brandid, brand
FROM brand
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTCATEGORY]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTCATEGORY]
@vCATEGORY VARCHAR(250)
AS
IF (SELECT COUNT(catid) FROM category WHERE category = @vCATEGORY) = 0
BEGIN
	INSERT INTO category (category)
	VALUES (@vCATEGORY)
END
SELECT catid, category 
FROM category
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTCATEGORYBRAND]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTCATEGORYBRAND]
--not sure using anymore
@biCATID BIGINT,
@biBRANDID BIGINT
AS
IF (SELECT COUNT(catbrandid) FROM categorybrand WHERE catid = @biCATID AND brandid = @biBRANDID) = 0
BEGIN
	--ONLY ALLOW ONE BRAND PER CATEGORY
	INSERT INTO categorybrand (catid, brandid)
	VALUES (@biCATID, @biBRANDID)
	
	SELECT SCOPE_IDENTITY() AS CATBRANDID
END
ELSE
BEGIN
	SELECT catbrandid 
	FROM categorybrand 
	WHERE  catid = @biCATID AND brandid = @biBRANDID
END
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTCUSTCART]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_INSERTCUSTCART]
@biCUSTID BIGINT,
@biINVENTORYID BIGINT,
@biQUANTITY BIGINT
AS
DECLARE  @biINVENTORYQTY BIGINT, @biNEWQTY BIGINT
 
IF (SELECT COUNT(custid) FROM cart WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL) = 0
BEGIN --NO DUPLICATES
	INSERT INTO cart (custid, inventoryid, quantity)
	VALUES (@biCUSTID, @biINVENTORYID, @biQUANTITY)
END
ELSE
BEGIN 
	SET @biNEWQTY = (SELECT (quantity + @biQUANTITY) FROM cart WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL)
	SET @biINVENTORYQTY = (SELECT quantity FROM inventory WHERE inventoryid = @biINVENTORYID )
	IF @biNEWQTY > @biINVENTORYQTY
	BEGIN
		SET @biNEWQTY = @biINVENTORYQTY
	END
	UPDATE cart 
	SET quantity = @biNEWQTY
	WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL
END

SELECT * FROM VU_CART
WHERE custid = @biCUSTID AND ordid IS NULL



GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTERROR]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTERROR]
@bASPNET BIT = 0,
@bAJAX BIT = 0,
@bSQLSERVER BIT = 0,
@nvERRORMSG NVARCHAR(3500) = '',
@nvPAGE NVARCHAR(250) = '',
@nvMETHOD NVARCHAR(250) = '',
@nvPROCEDURENAME NVARCHAR(250) = ''
AS
INSERT INTO error (aspnet, ajax, sqlserver, errormsg, page, method, procedurename)
VALUES(@bASPNET, @bAJAX, @bSQLSERVER, @nvERRORMSG, @nvPAGE, @nvMETHOD, @nvPROCEDURENAME)
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTIMAGE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTIMAGE]
@vbIMAGEDATA VARBINARY(MAX),
@uiINVENTORYGUIDID UNIQUEIDENTIFIER = NULL,
@biINVENTORYID BIGINT = NULL,
@bMAIN BIT = 0
AS
DECLARE @uiIMAGEGUIDID UNIQUEIDENTIFIER
IF @uiINVENTORYGUIDID IS NULL AND @biINVENTORYID IS NOT NULL
BEGIN
	SELECT @uiINVENTORYGUIDID = inventoryguidid
	FROM inventory
	WHERE inventoryid = @biINVENTORYID
END
IF (SELECT COUNT(imageid) FROM image WHERE inventoryguidid = @uiINVENTORYGUIDID) = 0
BEGIN --FIRST IMAGE IS MAIN IMAGE
	SET @bMAIN = 1
END
INSERT INTO IMAGE (imagedata, inventoryguidid, main)
VALUES (@vbIMAGEDATA, @uiINVENTORYGUIDID, @bMAIN)

SELECT @uiIMAGEGUIDID = imageguidid
FROM image
WHERE imageid = SCOPE_IDENTITY()

SELECT @uiIMAGEGUIDID AS IMAGEGUIDID
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTINVENTORY]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTINVENTORY]
	@biBRANDID BIGINT = 0,
	@biCATID BIGINT = 0,
	@nvPRODUCTNAME NVARCHAR(250),
	@nvDESCRIPTION NVARCHAR(3500),
	@nvYEAR NVARCHAR(10),
	@nvCOLOR NVARCHAR(150),
	@nvSIZE NVARCHAR(150),
	@biLOGONID BIGINT,	
	@biQUANTITY BIGINT,
	@bNEW BIT,
	@bUSED BIT,
	@dPRICE DECIMAL(19, 2),
	@bRECOMMENDITEM BIT
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(inventoryid) FROM inventory WHERE productname = @nvPRODUCTNAME) = 0
BEGIN
	SET @bDUPLICATE = 0
END
INSERT INTO INVENTORY (BRANDID,CATID,PRODUCTNAME,DESCRIPTION,YEAR,COLOR,SIZE,LOGONID,QUANTITY,NEW,USED,PRICE,RECOMMENDITEM)
VALUES(@biBRANDID,@biCATID,@nvPRODUCTNAME,@nvDESCRIPTION,@nvYEAR,@nvCOLOR,@nvSIZE,@biLOGONID,@biQUANTITY,@bNEW,@bUSED,@dPRICE,@bRECOMMENDITEM)

SELECT inventoryid, @bDUPLICATE AS DUPLICATE, inventoryguidid
FROM inventory
WHERE inventoryid = SCOPE_IDENTITY()
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTPRODUCTRELATE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_INSERTPRODUCTRELATE]
@biRELATEPRODID BIGINT,
@biCUSTID BIGINT,
@biINVENTORYID BIGINT
AS
DECLARE @biMAINPRODID BIGINT, @bDUPLICATE BIT = 0 --, @biPRODRELATEID BIGINT

SET @biMAINPRODID = (SELECT prodid FROM inventory WHERE inventoryid = @biINVENTORYID)
 
IF (SELECT COUNT(prodrelateid) FROM productrelate WHERE custid = @biCUSTID AND mainprodid = @biMAINPRODID AND relateprodid = @biRELATEPRODID) = 0 
	AND (@biMAINPRODID <> @biRELATEPRODID)
BEGIN --NO DUPLICATES AND MAINPRODUCT CANT EQUAL RELATEPRODUCT
	INSERT INTO productrelate (mainprodid, relateprodid, custid)
	VALUES(@biMAINPRODID, @biRELATEPRODID, @biCUSTID)
	--SET @biPRODRELATEID = SCOPE_IDENTITY()
END 
ELSE 
BEGIN --SET DUPLICATE ENTRY
	SET @bDUPLICATE = 1
END
--FILL TEMP TABLE WITH NEW UNIQUE PRODUCT RELATE
SELECT v.product as relateproduct,  v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
INTO #temp
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.new = 1
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID

ALTER TABLE #TEMP ADD PRIMARY KEY CLUSTERED 
(	PRODRELATEID ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--FIND MISSING UNIQUE USED PRODUCT NOT FILLED BY NEW UNIQUE PRODUCT
INSERT INTO #temp (relateproduct, relatedescription, relateyear, relateurl, PRODRELATEID)
SELECT v.product as relateproduct, v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.used = 1 --multiple used product !! WARNING YOU NEED TO GET ONLY 1 USED PRODUCT!!
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID
ORDER BY relateurl DESC

SELECT * FROM #temp



GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTSYSTEM]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SP_INSERTSYSTEM]
AS
IF (SELECT COUNT(systemid) FROM system) = 0
BEGIN
	INSERT INTO system (showmenu, showcategorytab)
	VALUES(1, 1)
END
GO

/****** Object:  StoredProcedure [dbo].[SP_INSERTVIDEO]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_INSERTVIDEO]
@vURL NVARCHAR(3500),
@uiINVENTORYGUIDID UNIQUEIDENTIFIER,
@bYOUTUBE BIT
AS
IF (SELECT COUNT(videoid) FROM video WHERE inventoryguidid = @uiINVENTORYGUIDID AND url = @vURL) = 0
BEGIN --INSERT NEW VIDEO
	INSERT INTO video (url, inventoryguidid, youtube)
	VALUES (@vURL, @uiINVENTORYGUIDID, @bYOUTUBE)
END

SELECT videoid, url, inventoryguidid, youtube 
FROM video 
WHERE inventoryguidid = @uiINVENTORYGUIDID 
GO

/****** Object:  StoredProcedure [dbo].[SP_INVENTORYFILTER]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_INVENTORYFILTER]
@biCATID BIGINT,
@biBRANDID BIGINT,
@bNEW BIT,
@bUSED BIT,
@dPRICESTART DECIMAL(19,2),
@dPRICEEND DECIMAL(19,2)
AS --NEED TO ANALYZE THIS OUTPUT ALSO NEED TO SEE IF ENTITY FRAMEWORK CAN MAKE THIS EASIER TO USE
SELECT p.product, p.description, p.year, i.inventoryid, g.url, g.imageid, c.color, s.size, cc.displayname, --NEEDED VALUES
i.brandid, i.prodid, i.custid, i.sizeid, i.colorid, i.quantity, i.new, i.used, i.price, i.catid --EXTRA VALUES
INTO #temp
FROM inventory i INNER JOIN product p ON i.prodid = p.prodid --1 to 1
INNER JOIN image g ON i.inventoryid = g.inventoryid  --1 to MANY
INNER JOIN color c ON i.colorid = c.colorid --1 TO 1
INNER JOIN size s ON s.sizeid = i.sizeid -- 1 TO 1
INNER JOIN customer cc ON i.custid = cc.custid
WHERE (i.new = @bNEW OR i.used = @bUSED) 
AND (i.price >= @dPRICESTART AND i.price <= @dPRICEEND)

IF @biCATID <> 0 AND @biBRANDID <> 0
BEGIN 
	DELETE FROM #temp 
	WHERE (catid <> @biCATID AND brandid <> @biBRANDID)
END

SELECT *
FROM #temp

DELETE #temp



GO

/****** Object:  StoredProcedure [dbo].[SP_INVENTORYIDSEARCH]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_INVENTORYIDSEARCH]
@biINVENTORYID BIGINT
AS --NEED TO ANALYZE THIS OUTPUT ALSO NEED TO SEE IF ENTITY FRAMEWORK CAN MAKE THIS EASIER TO USE
SELECT p.product, p.description, p.year, i.inventoryid, g.url, g.imageid, c.color, s.size, cc.displayname, --NEEDED VALUES
i.brandid, i.prodid, i.custid, i.sizeid, i.colorid, i.quantity, i.new, i.used, i.price, i.catid --EXTRA VALUES
FROM inventory i INNER JOIN product p ON i.prodid = p.prodid --1 to 1
LEFT JOIN image g ON i.inventoryid = g.inventoryid  --1 to MANY
INNER JOIN color c ON i.colorid = c.colorid --1 TO 1
INNER JOIN size s ON s.sizeid = i.sizeid -- 1 TO 1
INNER JOIN customer cc ON i.custid = cc.custid
WHERE i.inventoryid = @biINVENTORYID 



GO

/****** Object:  StoredProcedure [dbo].[SP_INVENTORYSEARCH]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_INVENTORYSEARCH]
@biCATID BIGINT,
@biBRANDID BIGINT,
@bNEW BIT,
@bUSED BIT,
@dPRICESTART DECIMAL(19,2),
@dPRICEEND DECIMAL(19,2)
AS --NEED TO ANALYZE THIS OUTPUT ALSO NEED TO SEE IF ENTITY FRAMEWORK CAN MAKE THIS EASIER TO USE
SELECT p.product, p.description, p.year, i.inventoryid, g.url, g.imageid, c.color, s.size, cc.displayname, --NEEDED VALUES
i.brandid, i.prodid, i.custid, i.sizeid, i.colorid, i.quantity, i.new, i.used, i.price, i.catid --EXTRA VALUES
FROM inventory i INNER JOIN product p ON i.prodid = p.prodid --1 to 1
INNER JOIN image g ON i.inventoryid = g.inventoryid  --1 to MANY
INNER JOIN color c ON i.colorid = c.colorid --1 TO 1
INNER JOIN size s ON s.sizeid = i.sizeid -- 1 TO 1
INNER JOIN customer cc ON i.custid = cc.custid
WHERE i.brandid = @biBRANDID AND (i.price >= @dPRICESTART AND i.price <= @dPRICEEND) AND (i.new = @bNEW OR i.used = @bUSED)
ORDER BY p.product ASC, i.inventoryid ASC



GO

/****** Object:  StoredProcedure [dbo].[SP_LOGONPRODINSERT]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_LOGONPRODINSERT]
@nvUSERNAME NVARCHAR(150),
@nvPASSWORD NVARCHAR(150)
AS
BEGIN
	DECLARE @iCNT INT
	SET @iCNT = (SELECT COUNT(LOGONID) FROM logonprodupload)
	IF @iCNT = 0
	BEGIN
		INSERT INTO logonprodupload (username, password)
		VALUES (@nvUSERNAME, @nvPASSWORD)
	END
	ELSE
	BEGIN
		--Check if username password exist if not insert it
		IF (SELECT COUNT(LOGONID) FROM logonprodupload WHERE username = @nvUSERNAME AND password = @nvPASSWORD) = 0
		BEGIN		
			INSERT INTO logonprodupload (username, password)
			VALUES (@nvUSERNAME, @nvPASSWORD)
		END
	END
END
GO

/****** Object:  StoredProcedure [dbo].[SP_LOGONPRODUPLOAD]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_LOGONPRODUPLOAD]
@nvUSERNAME NVARCHAR(150),
@nvPASSWORD NVARCHAR(150)
AS
BEGIN
	DECLARE @biLOGONID BIGINT = 0
	SELECT @biLOGONID = LOGONID
	FROM logonprodupload
	WHERE username = @nvUSERNAME AND password = @nvPASSWORD

	SELECT @biLOGONID
END
GO

/****** Object:  StoredProcedure [dbo].[SP_MAINIMAGEID]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_MAINIMAGEID]
@biINVENTORYID BIGINT,
@biIMAGEID BIGINT
AS
UPDATE image
SET main = 0
WHERE inventoryid = @biINVENTORYID

UPDATE image
SET main = 1
WHERE imageid = @biIMAGEID



GO

/****** Object:  StoredProcedure [dbo].[SP_MAININVENTORYIDSEARCH]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_MAININVENTORYIDSEARCH]
@biINVENTORYID BIGINT
AS --NEED TO ANALYZE THIS OUTPUT ALSO NEED TO SEE IF ENTITY FRAMEWORK CAN MAKE THIS EASIER TO USE
SELECT p.product, p.description, p.year, i.inventoryid, g.url, g.imageid, c.color, s.size, cc.displayname, i.AUTHNET, i.CASHDIRECT, i.PAYPAL,--NEEDED VALUES
i.brandid, i.prodid, i.custid, i.sizeid, i.colorid, i.quantity, i.new, i.used, i.price, i.catid --EXTRA VALUES
FROM inventory i INNER JOIN product p ON i.prodid = p.prodid --1 to 1
INNER JOIN image g ON i.inventoryid = g.inventoryid  --1 to MANY
INNER JOIN color c ON i.colorid = c.colorid --1 TO 1
INNER JOIN size s ON s.sizeid = i.sizeid -- 1 TO 1
INNER JOIN customer cc ON i.custid = cc.custid
WHERE i.quantity <> 0 AND g.main = 1
AND i.inventoryid = @biINVENTORYID



GO

/****** Object:  StoredProcedure [dbo].[SP_PRODUCTAUTOCOMPLETE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_PRODUCTAUTOCOMPLETE]
@vPRODSEARCH VARCHAR(300),
@biBRANDID BIGINT,
@biCATID BIGINT,
@biCUSTID BIGINT,
@vYEAR VARCHAR(10)
AS
SELECT year + ' ' + product as year_prod, prodid
FROM vu_inventory 
WHERE (main = 1 AND brandid = @biBRANDID AND catid = @biCATID AND year = @vYEAR AND custid = @biCUSTID)
AND (product LIKE @vPRODSEARCH OR (year + ' ' + product + ' ' + size + ' ' + color) LIKE @vPRODSEARCH
OR description LIKE @vPRODSEARCH)
GROUP BY year + ' ' + product, prodid



GO

/****** Object:  StoredProcedure [dbo].[SP_PRODUCTRELATE]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_PRODUCTRELATE]
@biCUSTID BIGINT,
@biINVENTORYID BIGINT
AS
DECLARE @biMAINPRODID BIGINT
SET @biMAINPRODID = (SELECT prodid FROM inventory WHERE inventoryid = @biINVENTORYID)

--FILL TEMP TABLE WITH NEW UNIQUE PRODUCT RELATE
SELECT v.product as relateproduct,  v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
INTO #temp
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.new = 1
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID

ALTER TABLE #TEMP ADD PRIMARY KEY CLUSTERED 
(	PRODRELATEID ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--FIND MISSING UNIQUE USED PRODUCT NOT FILLED BY NEW UNIQUE PRODUCT
INSERT INTO #temp (relateproduct, relatedescription, relateyear, relateurl, PRODRELATEID)
SELECT v.product as relateproduct, v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.used = 1 --multiple used product !! WARNING YOU NEED TO GET ONLY 1 USED PRODUCT!!
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID
ORDER BY relateurl DESC

SELECT * FROM #temp





GO

/****** Object:  StoredProcedure [dbo].[SP_PRODUCTRELATERESULT]    Script Date: 11/16/2017 12:56:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[SP_PRODUCTRELATERESULT]
@biCATID BIGINT,
@biBRANDID BIGINT,
@biPRODID BIGINT,
@vYEAR VARCHAR(10),
@biCUSTID BIGINT
AS
SELECT TOP 1 product, description, year, inventoryid, url, color, size, price, new, used, prodid, quantity, displayname
FROM vu_inventory 
WHERE brandid = @biBRANDID AND catid = @biCATID AND year = @vYEAR AND custid = @biCUSTID AND prodid = @biPRODID
ORDER BY main DESC, new DESC



GO

/****** Object:  StoredProcedure [dbo].[sp_SEARCH]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROC [dbo].[sp_SEARCH]
(@biCATID BIGINT,
 @biBRANDID BIGINT,
 @bNEW BIT,
 @bUSED BIT,
 @dPRICESTART DECIMAL(19,2),
 @dPRICEEND DECIMAL(19,2))
AS
SELECT i.inventoryid, i.brandid, i.prodid, i.custid, i.sizeid, i.quantity, i.new, i.price, u.url
FROM inventory i INNER JOIN imageurl u ON i.inventoryid = u.inventoryid
WHERE i.catid = @biCATID AND i.brandid = @biBRANDID AND i.new = @bNEW AND i.new = @bUSED AND (i.price >= @dPRICESTART AND i.price <= @dPRICESTART)



GO

/****** Object:  StoredProcedure [dbo].[SP_TEST]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[SP_TEST]
(@vSQL VARCHAR(1000) = '')
AS
EXEC('SELECT * FROM inventory')

GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATEBRAND]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATEBRAND]
@biBRANDID BIGINT,
@vBRAND VARCHAR(250)
AS
IF (SELECT COUNT(brandid) FROM brand WHERE brand = @vBRAND) = 0
BEGIN
	UPDATE brand
	SET brand = @vBRAND
	WHERE brandid = @biBRANDID
END

SELECT brandid, brand
FROM brand
ORDER BY brand
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATECART]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[SP_UPDATECART]
@biCUSTID BIGINT,
@biQUANTITY BIGINT,
@biINVENTORYID BIGINT
AS
DECLARE @vSUBTOTAL VARCHAR(30),@biINVENTORYQTY BIGINT, @iCartItemCount INT
SET @biINVENTORYQTY = (SELECT quantity FROM inventory WHERE inventoryid = @biINVENTORYID )
IF @biQUANTITY > @biINVENTORYQTY
BEGIN --FORCES QUANTITY TO ALWAYS BE LOWER THAN INVENTORY QTY
	SET @biQUANTITY = @biINVENTORYQTY
END		
UPDATE cart 
SET quantity = ISNULL(@biQUANTITY, 0)
WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL

SET @vSUBTOTAL = (SELECT FORMAT(SUM(quantity * price),'C', 'en-us') FROM VU_CART WHERE custid = @biCUSTID AND ordid IS NULL)
SET @iCartItemCount = (SELECT SUM(quantity) FROM vu_cart WHERE custid = @biCUSTID AND ordid IS NULL)
SELECT quantity, inventoryqty, year, product, size, url, price, FORMAT(quantity * price,'C', 'en-us') as itemtotal, @vSUBTOTAL as subtotal,  inventoryid, @iCartItemCount as cartitemcount
FROM VU_CART 
WHERE custid = @biCUSTID AND inventoryid = @biINVENTORYID AND ordid IS NULL




GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATECATEGORY]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATECATEGORY]
@biCATID BIGINT,
@vCATEGORY VARCHAR(250)
AS
IF (SELECT COUNT(catid) FROM category WHERE category = @vCATEGORY) = 0
BEGIN
	UPDATE category 
	SET category = @vCATEGORY
	WHERE catid = @biCATID
END
SELECT catid, category
FROM category
ORDER BY category ASC
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATECATEGORYBRAND]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATECATEGORYBRAND]
@biCATBRANDID BIGINT,
@biCATID BIGINT,
@biBRANDID BIGINT
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(catbrandid) FROM categorybrand WHERE catid = @biCATID AND brandid = @biBRANDID) = 0
BEGIN
	--ONLY ALLOW ONE BRAND PER CATEGORY
	UPDATE categorybrand 
	SET catid = @biCATID, brandid = @biBRANDID
	WHERE catbrandid = @biCATBRANDID
	SET @bDUPLICATE = 0
END

SELECT @bDUPLICATE AS DUPLICATE
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATECATEGORYMENUTAB]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATECATEGORYMENUTAB]
@biCATID BIGINT,
@bSHOWCATEGORYMENU BIT,
@bSHOWCATEGORYTAB BIT
AS
UPDATE category
SET showcategorymenu = @bSHOWCATEGORYMENU, showcategorytab = @bSHOWCATEGORYTAB
WHERE catid = @biCATID
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATECOLOR]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[SP_UPDATECOLOR]
@biCOLORID BIGINT,
@vCOLOR VARCHAR(250),
@biPRODID BIGINT
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(colorid) FROM color WHERE color = @vCOLOR AND prodid = @biPRODID) = 0
BEGIN
	UPDATE color 
	SET color = @vCOLOR, prodid = @biPRODID
	WHERE colorid = @biCOLORID
	SET @bDUPLICATE = 0
END

SELECT @bDUPLICATE AS DUPLICATE




GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATEINVENTORY]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATEINVENTORY]
	@biINVENTORYID BIGINT,
	@biBRANDID BIGINT = 0,
	@biCATID BIGINT = 0,
	@nvPRODUCTNAME NVARCHAR(250),
	@nvDESCRIPTION NVARCHAR(3500),
	@nvYEAR NVARCHAR(10),
	@nvCOLOR NVARCHAR(150),
	@nvSIZE NVARCHAR(150),
	@biLOGONID BIGINT,	
	@biQUANTITY BIGINT,
	@bNEW BIT,
	@bUSED BIT,
	@dPRICE DECIMAL(19, 2),
	@bRECOMMENDITEM BIT
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(inventoryid) FROM inventory WHERE productname = @nvPRODUCTNAME) = 0
BEGIN
	SET @bDUPLICATE = 0
END
UPDATE INVENTORY 
SET BRANDID = @biBRANDID, productname = @nvPRODUCTNAME, description = @nvDESCRIPTION, year = @nvYEAR, logonid = @biLOGONID,size = @nvSIZE,color = @nvCOLOR,
QUANTITY = @biQUANTITY,NEW = @bNEW,PRICE = @dPRICE,CATID= @biCATID,USED = @bUSED, recommenditem = @bRECOMMENDITEM
WHERE inventoryid = @biINVENTORYID
SELECT @bDUPLICATE AS DUPLICATE
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATEPRODUCT]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [dbo].[SP_UPDATEPRODUCT]
@biPRODID BIGINT,
@nvPRODUCT NVARCHAR(250),
@nvDESCRIPTION NVARCHAR(3500),
@biBRANDID BIGINT,
@vYEAR VARCHAR(10)
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(prodid) FROM product WHERE product = @nvPRODUCT AND year = @vYEAR AND brandid = @biBRANDID) = 0
BEGIN
	--ONLY NEW PRODUCT AND YEAR ALLOWED TO INSERT
	UPDATE product 
	SET product = @nvPRODUCT, description = @nvDESCRIPTION, brandid = @biBRANDID, year = @vYEAR
	WHERE prodid = @biPRODID
	SET @bDUPLICATE = 0
END

SELECT @bDUPLICATE AS DUPLICATE





GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATEPRODUCTRELATE]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[SP_UPDATEPRODUCTRELATE]
@biPRODRELATEID BIGINT,
@biMAINPRODID BIGINT,
@biRELATEPRODID BIGINT,
@biCUSTID BIGINT
AS
DECLARE @bDUPLICATE BIT = 0
IF (SELECT COUNT(prodrelateid) FROM productrelate WHERE mainprodid = @biMAINPRODID AND relateprodid = @biRELATEPRODID) = 0
BEGIN --NO DUPLICATES
	UPDATE productrelate 
	SET  mainprodid = @biMAINPRODID, relateprodid = @biRELATEPRODID
	WHERE prodrelateid = @biPRODRELATEID
END 
ELSE 
BEGIN --RETURN DUPLICATE
	SET @bDUPLICATE = 1
END

--FILL TEMP TABLE WITH NEW UNIQUE PRODUCT RELATE
SELECT v.product as relateproduct,  v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
INTO #temp
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.new = 1
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID

ALTER TABLE #TEMP ADD PRIMARY KEY CLUSTERED 
(	PRODRELATEID ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = ON, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)

--FIND MISSING UNIQUE USED PRODUCT NOT FILLED BY NEW UNIQUE PRODUCT
INSERT INTO #temp (relateproduct, relatedescription, relateyear, relateurl, PRODRELATEID)
SELECT v.product as relateproduct, v.description as relatedescription,  v.year as relateyear,  v.url as relateurl, p.PRODRELATEID
FROM vu_inventory v INNER JOIN productrelate p ON v.prodid = p.relateprodid
WHERE v.main = 1 AND v.used = 1 --multiple used product !! WARNING YOU NEED TO GET ONLY 1 USED PRODUCT!!
AND p.custid = @biCUSTID AND p.mainprodid = @biMAINPRODID
ORDER BY relateurl DESC

SELECT * FROM #temp





GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATESHOWCATEGORYTAB]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATESHOWCATEGORYTAB]
@bSHOWCATEGORYTAB BIT
AS
UPDATE system
SET showcategorytab = @bSHOWCATEGORYTAB
WHERE systemid = 1
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATESHOWMENU]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATESHOWMENU]
@bSHOWMENU BIT
AS
UPDATE system
SET showmenu = @bSHOWMENU
WHERE systemid = 1
GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATESIZE]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [dbo].[SP_UPDATESIZE]
@biSIZEID BIGINT,
@vSIZE VARCHAR(250),
@biPRODID BIGINT,
@biCAT BIGINT
AS
DECLARE @bDUPLICATE BIT = 1
IF (SELECT COUNT(sizeid) FROM size WHERE size = @vSIZE AND prodid = @biPRODID AND catid = @biCAT) = 0
BEGIN
	--ONLY ALLOWS INSERT NEW SIZES FOR EACH PRODUCT CATEGORY
	UPDATE size 
	SET size = @vSIZE, prodid = @biPRODID, catid = @biCAT
	WHERE sizeid = @biSIZEID
	SET @bDUPLICATE = 0
END

SELECT @bDUPLICATE AS DUPLICATE




GO

/****** Object:  StoredProcedure [dbo].[SP_UPDATEVIDEO]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UPDATEVIDEO]
@biVIDEOID BIGINT,
@vURL NVARCHAR(3500),
@uiINVENTORYGUIDID UNIQUEIDENTIFIER,
@bYOUTUBE BIT
AS
IF (SELECT COUNT(videoid) FROM video WHERE inventoryguidid = @uiINVENTORYGUIDID AND url = @vURL) = 0
BEGIN --UPDATE NEW VIDEO
	UPDATE video
	SET url = @vURL, inventoryguidid = @uiINVENTORYGUIDID, youtube = @bYOUTUBE
	WHERE videoid = @biVIDEOID
END
SELECT videoid, url, inventoryguidid, youtube 
FROM video 
WHERE inventoryguidid = @uiINVENTORYGUIDID 
GO

/****** Object:  StoredProcedure [dbo].[SP_VIDEO]    Script Date: 11/16/2017 12:56:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_VIDEO]
@uiINVENTORYGUIDID UNIQUEIDENTIFIER
AS
SELECT videoid, url, inventoryid, youtube 
FROM video 
WHERE inventoryguidid = @uiINVENTORYGUIDID
GO

USE [eSHOP]
GO

/****** Object:  UserDefinedFunction [dbo].[Split]    Script Date: 11/16/2017 12:56:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE FUNCTION [dbo].[Split]
(
	@RowData nvarchar(2000),
	@SplitOn nvarchar(5)
)  
RETURNS @RtnValue TABLE 
(
	Id int IDENTITY(1,1),
	Data VARCHAR(100)
) 
AS  
BEGIN 
	DECLARE @Cnt INT
	SET @Cnt = 1

	WHILE (CHARINDEX(@SplitOn,@RowData)>0)
	BEGIN
		INSERT INTO @RtnValue (data)
		SELECT 
			Data = LTRIM(RTRIM(SUBSTRING(@RowData,1,CHARINDEX(@SplitOn, @RowData) - 1)))

		SET @RowData = SUBSTRING(@RowData, CHARINDEX(@SplitOn,@RowData) + 1, LEN(@RowData))
		SET @Cnt = @Cnt + 1
	END
	
	INSERT INTO @RtnValue (data)
	SELECT DATA = LTRIM(RTRIM(@RowData))

	RETURN
END



GO

USE [eSHOP]
GO

/****** Object:  UserDefinedFunction [dbo].[sf_MMDDYYYY]    Script Date: 11/16/2017 12:56:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE FUNCTION [dbo].[sf_MMDDYYYY]
(@vDATE DATETIME)
RETURNS VARCHAR(15)
AS
BEGIN
	RETURN CONVERT(VARCHAR(5), DATEPART(MM, @vDATE)) + '/' +
	CONVERT(VARCHAR(5), DATEPART(DD, @vDATE)) + '/' +
	CONVERT(VARCHAR(5), DATEPART(YYYY, @vDATE))
END




GO

/****** Object:  UserDefinedFunction [dbo].[TRIM]    Script Date: 11/16/2017 12:56:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE FUNCTION [dbo].[TRIM]
(@vValue VARCHAR(4000))
RETURNS VARCHAR(4000)
AS
BEGIN
	RETURN LTRIM(RTRIM(@vValue))
END




GO

