cd C:\Windows\Microsoft.NET\Framework\v4.0.30319

aspnet_regsql  -ssadd  -d SQLSessionTable  -S LAPTOP-ASH6NMMV\SQLEXPRESS -E �sstype  c  -sqlexportonly "C:\Users\Dominic\Desktop\test\test.sql"