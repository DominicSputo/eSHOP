﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
   
    public class LogError
    {
        private static string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOPERROR"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";

        public static void InsertError(string sPage, string sMethod, string sError, string sProcedureName)
        {
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_INSERTERROR", con);
                cmd.Parameters.Add("@bASPNET", SqlDbType.Bit).Value = true;
                cmd.Parameters.Add("@nvERRORMSG", SqlDbType.NVarChar).Value = sError;
                cmd.Parameters.Add("@nvPAGE", SqlDbType.NVarChar).Value = sPage;
                cmd.Parameters.Add("@nvMETHOD", SqlDbType.NVarChar).Value = sMethod;
                cmd.Parameters.Add("@nvPROCEDURENAME", SqlDbType.NVarChar).Value = sProcedureName;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
        }



    }
}