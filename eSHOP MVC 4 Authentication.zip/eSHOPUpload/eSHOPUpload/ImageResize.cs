﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.IO;

namespace eSHOPUpload
{
    #region ImageResize CLASS
    /// <summary>
    /// ImageResize is a class that is based on an article that was obtained from
    /// the URL http://www.devx.com/dotnet/Article/22079/0/page/3. I had to make
    /// https://www.codeproject.com/Articles/17041/SQL-Database-Image-Storage-Easy-Thumbnails?msg=2422416
    /// some minor changes to a couple of the properties, but otherwise it is very
    /// much like the original article.
    /// </summary>
    public class ImageResize
    {
        #region Instance Fields
        //instance fields
        private double d_Width, d_Height;
        private bool b_Use_Aspect = true;
        private bool b_Use_Percentage = false;
        private System.Drawing.Image img_SourceImage, img_DestinationImage;
        private System.Drawing.Image img_Image;
        private ImageResize m_cache;
        private Graphics m_graphics;
        #endregion
        #region Public properties
        /// <summary>
        /// gets of sets the File
        /// </summary>
        public System.Drawing.Image File
        {
            get { return img_Image; }
            set { img_Image = value; }
        }
        /// <summary>
        /// gets of sets the Image
        /// </summary>
        public System.Drawing.Image Image
        {
            get { return img_SourceImage; }
            set { img_SourceImage = value; }
        }
        /// <summary>
        /// gets of sets the PreserveAspectRatio
        /// </summary>
        public bool PreserveAspectRatio
        {
            get { return b_Use_Aspect; }
            set { b_Use_Aspect = value; }
        }
        /// <summary>
        /// gets of sets the UsePercentages
        /// </summary>
        public bool UsePercentages
        {
            get { return b_Use_Percentage; }
            set { b_Use_Percentage = value; }
        }
        /// <summary>
        /// gets of sets the Width
        /// </summary>
        public double Width
        {
            get { return d_Width; }
            set { d_Width = value; }
        }
        /// <summary>
        /// gets of sets the Height
        /// </summary>
        public double Height
        {
            get { return d_Height; }
            set { d_Height = value; }
        }
        #endregion
        #region Public Methods
        /// <summary>
        /// Returns a Image which represents a rezised Image
        /// </summary>
        /// <returns>A Image which represents a rezised Image, using the 
        /// proprerty settings provided</returns>
        public virtual System.Drawing.Image GetImage()
        {
            // Flag whether a new image is required
            bool recalculate = false;
            double new_width = Width;
            double new_height = Height;
            // Load via stream rather than Image.FromFile to release the file
            // handle immediately
            if (img_SourceImage != null)
                img_SourceImage.Dispose();
            img_SourceImage = img_Image;
            recalculate = true;
            // If you opted to specify width and height as percentages of the 
            // original image's width and height, compute these now
            if (UsePercentages)
            {
                if (Width != 0)
                {
                    new_width = (double)img_SourceImage.Width * Width / 100;

                    if (PreserveAspectRatio)
                    {
                        new_height = new_width * img_SourceImage.Height /
                            (double)img_SourceImage.Width;
                    }
                }
                if (Height != 0)
                {
                    new_height = (double)img_SourceImage.Height * Height / 100;

                    if (PreserveAspectRatio)
                    {
                        new_width = new_height * img_SourceImage.Width /
                            (double)img_SourceImage.Height;
                    }
                }
            }
            else
            {
                // If you specified an aspect ratio and absolute width or height,
                // then calculate this now; if you accidentally specified both a 
                // width and height, ignore the PreserveAspectRatio flag

                if (PreserveAspectRatio)
                {
                    if (Width != 0 && Height == 0)
                    {
                        new_height = (Width / (
                            double)img_SourceImage.Width) * img_SourceImage.Height;
                    }
                    else if (Height != 0 && Width == 0)
                    {
                        new_width = (Height / (
                            double)img_SourceImage.Height) * img_SourceImage.Width;
                    }
                }
            }
            recalculate = true;
            if (recalculate)
            {
                // Calculate the new image
                if (img_DestinationImage != null)
                {
                    img_DestinationImage.Dispose();
                    m_graphics.Dispose();
                }
                Bitmap bitmap = new Bitmap((int)new_width, (int)new_height, img_SourceImage.PixelFormat);
                m_graphics = Graphics.FromImage(bitmap);
                m_graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                m_graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                m_graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality; //NEW CODE
                m_graphics.DrawImage(img_SourceImage, 0, 0, bitmap.Width, bitmap.Height);
                img_DestinationImage = bitmap;
                // Cache the image and its associated settings
                m_cache = this.MemberwiseClone() as ImageResize;
            }
            return img_DestinationImage;
        }
        #endregion
        #region Deconstructor
        /// <summary>
        /// Frees all held resources, such as Graphics and Image handles
        /// </summary>
        ~ImageResize()
        {
            // Free resources
            if (img_DestinationImage != null)
            {
                img_DestinationImage.Dispose();
                m_graphics.Dispose();
            }

            if (img_SourceImage != null)
                img_SourceImage.Dispose();
        }
        #endregion
    }
    #endregion
}



