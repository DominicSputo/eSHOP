﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
    public partial class ProductUpload : Page
    {
        string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";

        public class InsertID
        {
            public long iINVENTORYID { get; set; }

            public Guid guINVENTORYGUIDID { get; set; }

            public string sROLLBACK_REASON_MSG { get; set; }

            public bool bDUPLICATE { get; set; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            {
                btnAddProduct.Visible = true;
                btnUpdateProduct.Visible = false;
            }
            else
            {
                if (!IsPostBack)
                {
                    LoadVideo();
                }
                btnUpdateProduct.Visible = true;
                btnAddProduct.Visible = false;
            }
            Brand();
            Category();
        }

        public void LoadVideo()
        {
            if (ViewState["INVENTORYID"] + "" != "")
            {
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_VIDEO", con);
                cmd.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = ViewState["INVENTORYGUIDID"] + "";
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
        }

        public void sCategoryBrandValue(ref string sCategory, ref string sBrand)
        {
            if (sCategory == "")
            {
                sCategory = "0"; //means no value selected for category brand. they dont want to use category brand feature or didnt select value
            }
            if (sBrand == "")
            {
                sBrand = "0"; //means no value selected for category brand. they dont want to use category brand feature or didnt select value
            }
        }

        public bool Insert()
        {
            lblError.Text = "";
            string sCategory = ddlCategory.SelectedValue;
            string sBrand = ddlBrand.SelectedValue;
            sCategoryBrandValue(ref sCategory, ref sBrand);
            InsertID insertId = new InsertID();
            bool flag = false;
            //VALIDATION CHECK
            if (txtProduct.Value.Trim() == "")
            {
                lblError.Text = "Product Name is required!";
                txtProduct.Focus();
                return false;
            }
            if (txtPrice.Value.Trim() == "")
            {
                lblError.Text = "Product Price is required!";
                txtPrice.Focus();
                return false;
            }
            if (txtQuantity.Value.Trim() == "")
            {
                txtQuantity.Value = "0";
            }
            using (SqlConnection connection = new SqlConnection(sConnection))
            {
                try
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            if (sCategory != "0" && sBrand != "0")
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTCATEGORYBRAND", connection, transaction))
                                {//insert category brand if doesnt exist check in proc
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //iCATID;
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // iBRANDID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    //if (sqlDataReader.HasRows)
                                    //{
                                    //    while (sqlDataReader.Read())
                                    //        insertId.iCATBRANDID = long.Parse(sqlDataReader["CATBRANDID"].ToString());
                                    //}
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTINVENTORY", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = sBrand; // (object)iBRANDID;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = sCategory; // iCATID;
                                    sqlCommand.Parameters.Add("@nvPRODUCTNAME", SqlDbType.NVarChar).Value = txtProduct.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvYEAR", SqlDbType.NVarChar).Value = txtYear.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvCOLOR", SqlDbType.NVarChar).Value = txtColor.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvSIZE", SqlDbType.NVarChar).Value = txtSize.Value.Trim();
                                    sqlCommand.Parameters.Add("@biLOGONID", SqlDbType.BigInt).Value = Session["LOGONID"] + ""; //(object)iCUSTID;
                                    sqlCommand.Parameters.Add("@biQUANTITY", SqlDbType.BigInt).Value = txtQuantity.Value.Trim(); // iQUANTITY;
                                    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit).Value = rblNew.Checked;
                                    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit).Value = rblUsed.Checked;
                                    sqlCommand.Parameters.Add("@dPRICE", SqlDbType.Decimal).Value = txtPrice.Value.Trim(); // dPRICE;
                                    sqlCommand.Parameters.Add("@bRECOMMENDITEM", SqlDbType.Bit).Value = cbkRecommendItem.Checked;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                        {
                                            insertId.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
                                            insertId.guINVENTORYGUIDID = Guid.Parse(sqlDataReader["INVENTORYGUIDID"].ToString());
                                            insertId.bDUPLICATE = bool.Parse(sqlDataReader["DUPLICATE"].ToString());
                                        }
                                    }
                                    else
                                    {
                                        flag = true;
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "INVENTORY INSERT FAILED";
                                    }
                                    sqlDataReader.Close();
                                    if (insertId.bDUPLICATE)
                                    {
                                        insertId.sROLLBACK_REASON_MSG = "Successfully saved! Warning! Product already entered.";
                                    }
                                }
                            }
                            if (!flag)
                            {
                                transaction.Commit();
                                connection.Close();
                                ViewState["INVENTORYID"] = insertId.iINVENTORYID;
                                ViewState["INVENTORYGUIDID"] = insertId.guINVENTORYGUIDID;
                                InsertYouTube();
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            insertId.sROLLBACK_REASON_MSG = ex.ToString();
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connection.Close();
                }
                //return insertId;
            }
            if (insertId.sROLLBACK_REASON_MSG + "" != "")
            {
                lblError.Text = insertId.sROLLBACK_REASON_MSG;
                if (insertId.bDUPLICATE)
                {// The message is about item being a duplicate
                    ViewState["INVENTORYID"] = insertId.iINVENTORYID;
                }
            }
            else
            {
                ViewState["INVENTORYID"] = insertId.iINVENTORYID;
            }
            return flag;
        }

        public bool Update()
        {
            string sCategory = ddlCategory.SelectedValue;
            string sBrand = ddlBrand.SelectedValue;
            sCategoryBrandValue(ref sCategory, ref sBrand);
            InsertID insertId = new InsertID();
            bool flag = false;
            //VALIDATION CHECK
            if (txtProduct.Value.Trim() == "")
            {
                lblError.Text = "Product Name is required!";
                txtProduct.Focus();
                return false;
            }
            if (txtPrice.Value.Trim() == "")
            {
                lblError.Text = "Product Price is required!";
                txtPrice.Focus();
                return false;
            }
            if (txtQuantity.Value.Trim() == "")
            {
                txtQuantity.Value = "0";
            }
            using (SqlConnection connection = new SqlConnection(sConnection))
            {
                try
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            if (sCategory != "0" && sBrand != "0")
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATECATEGORYBRAND", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biCATBRANDID", SqlDbType.BigInt).Value = ViewState["CATBRANDID"] + ""; //(object)iCATBRANDID;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //(object)iCATID;
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // (object)iBRANDID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        //while (sqlDataReader.Read())
                                        //    ;
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "CATEGORY BRAND UPDATE FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATEINVENTORY", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = ViewState["INVENTORYID"] + ""; //(object)iINVENTORYID;
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = sBrand; // (object)iBRANDID;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = sCategory; // iCATID;
                                    sqlCommand.Parameters.Add("@nvPRODUCTNAME", SqlDbType.NVarChar).Value = txtProduct.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvYEAR", SqlDbType.NVarChar).Value = txtYear.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvCOLOR", SqlDbType.NVarChar).Value = txtColor.Value.Trim();
                                    sqlCommand.Parameters.Add("@nvSIZE", SqlDbType.NVarChar).Value = txtSize.Value.Trim();
                                    sqlCommand.Parameters.Add("@biLOGONID", SqlDbType.BigInt).Value = Session["LOGONID"] + ""; //(object)iCUSTID;
                                    sqlCommand.Parameters.Add("@biQUANTITY", SqlDbType.BigInt).Value = txtQuantity.Value.Trim(); // iQUANTITY;
                                    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit).Value = rblNew.Checked;
                                    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit).Value = rblUsed.Checked;
                                    sqlCommand.Parameters.Add("@dPRICE", SqlDbType.Decimal).Value = txtPrice.Value.Trim(); // dPRICE;
                                    sqlCommand.Parameters.Add("@bRECOMMENDITEM", SqlDbType.Bit).Value = cbkRecommendItem.Checked;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        //while (sqlDataReader.Read())
                                        //    ;
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "INVENTORY INSERT FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                    //if (insertId.bDUPLICATE)
                                    //    flag = true;
                                }
                            }
                            if (insertId.bDUPLICATE)
                            {
                                insertId.sROLLBACK_REASON_MSG = "Saved successfully! Warning! Product already entered.";
                                //transaction.Rollback();
                            }
                            if (!flag)
                            {
                                transaction.Commit();
                                connection.Close();
                                InsertYouTube();
                            }
                            //return insertId;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            insertId.sROLLBACK_REASON_MSG = ex.ToString();
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connection.Close();
                }
                //return insertId;
                if (insertId.sROLLBACK_REASON_MSG != "")
                {
                    lblError.Text = insertId.sROLLBACK_REASON_MSG;
                }
            }
            return flag;
        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            { //no new product insert
                if (!Insert())
                {
                    //NEED TO MAKE CLEAR FORM AND RESET FOR NEW ENTRY BELOW and CLEAR VIEWSTATE INVENTORYID
                    btnAddProduct.Visible = true;
                    btnUpdateProduct.Visible = false;
                }
            }
        }

        protected void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" != "")
            {
                Update();
            }
            btnAddProduct.Visible = false;
            btnUpdateProduct.Visible = true;
        }

     

        protected void btnAddYouTube_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            {
                if (!Insert())
                {
                    InsertYouTube();
                }
            }
            else
            {
                if (!Update())
                {
                    InsertYouTube();
                }
                InsertYouTube();
            }
        }

        public void InsertYouTube()
        {
            if (txtYouTube.Value.Trim() != "")
            {
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_INSERTVIDEO", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@vURL", SqlDbType.NVarChar).Value = txtYouTube.Value.Trim();
                cmd.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ViewState["INVENTORYGUIDID"] + "");
                cmd.Parameters.Add("@bYOUTUBE", SqlDbType.Bit).Value = true;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
        }

        public void Brand()
        {
            SqlConnection con = new SqlConnection(sConnection);
            SqlCommand cmd = new SqlCommand("SP_BRAND", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            ddlBrand.DataValueField = "BRANDID";
            ddlBrand.DataTextField = "BRAND";
            ddlBrand.DataSource = dt;
            ddlBrand.DataBind();
            con.Close();
        }

        public void Category()
        {
            SqlConnection con = new SqlConnection(sConnection);
            SqlCommand cmd = new SqlCommand("SP_CATEGORY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            ddlCategory.DataValueField = "CATID";
            ddlCategory.DataTextField = "CATEGORY";
            ddlCategory.DataSource = dt;
            ddlCategory.DataBind();
            con.Close();
        }

        protected void rptYouTube_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "UPDATE")
            {
                System.Web.UI.HtmlControls.HtmlInputControl txtYouTubeURL = (System.Web.UI.HtmlControls.HtmlInputControl)e.Item.FindControl("txtYouTubeURL");
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_UPDATEVIDEO", con);
                cmd.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = e.CommandArgument.ToString();
                cmd.Parameters.Add("@vURL", SqlDbType.NVarChar).Value = txtYouTubeURL.Value.Trim();
                cmd.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = ViewState["INVENTORYGUIDID"] + "";
                cmd.Parameters.Add("@bYOUTUBE", SqlDbType.Bit).Value = true;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
            else
            {
                System.Web.UI.HtmlControls.HtmlInputControl txtYouTubeURL = (System.Web.UI.HtmlControls.HtmlInputControl)e.Item.FindControl("txtYouTubeURL");
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_DELETEVIDEO", con);
                cmd.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = e.CommandArgument.ToString();
                cmd.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = ViewState["INVENTORYGUIDID"] + "";
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
        }
        
        protected void btnUploadImage_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            {
                Insert();
            }
            if (ViewState["INVENTORYID"] + "" != "")
            {
                if (fluImage.HasFile && fluImage.PostedFile.ContentType.ToLower().StartsWith("image"))
                {
                    cSQLDataImage cImage = new cSQLDataImage();
                    cImage.SP_INSERTIMAGE(bytIMAGEDATA: fluImage.FileBytes, iINVENTORYID: long.Parse(ViewState["INVENTORYID"] + ""), dMinWidth: 268, dMaxImageSizeMegaBytes: 1);
                    rptImage.DataSource = cImage.SP_IMAGEBYINV(iINVENTORYID: long.Parse(ViewState["INVENTORYID"] + ""));
                    rptImage.DataBind();
                }
            }
        }

        protected void rptImage_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

        }

        protected void rptImage_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
            {
                // get a reference to the image used for the bar in the row
                System.Web.UI.WebControls.Image imgImage = (System.Web.UI.WebControls.Image)(e.Item.FindControl("imgImage"));                
                // set the source to the page that generates the thumbnail image
                imgImage.ImageUrl = "Image.aspx?X=" + imgImage.Attributes["data-g"];
            }

        }
    }
}

//private bool bValidateImage(string sFileName)
//{
//    string sExtension = System.IO.Path.GetExtension(sFileName).ToLower();
//    switch (sExtension)
//    {
//        case ".jpg":
//            return true;
//        case ".png":
//            return true;
//        case ".gif":
//            return true;
//        case ".jpeg":
//            return true;
//        default:
//            return false;
//    }
//}

//using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATEPRODUCT", connection, transaction))
//{
//    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + "";  //(object)iPRODID;
//    sqlCommand.Parameters.Add("@nvPRODUCT", SqlDbType.NVarChar).Value = txtProduct.Value.Trim(); //(object)sPRODUCT;
//    sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim(); //(object)sDESCRIPTION;
//    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; //(object)iBRANDID;
//    sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = txtYear.Value.Trim(); //(object)sYEAR;
//    sqlCommand.CommandType = CommandType.StoredProcedure;
//    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//    if (sqlDataReader.HasRows)
//    {
//        while (sqlDataReader.Read())
//            ;
//    }
//    else
//    {
//        sqlDataReader.Close();
//        transaction.Rollback();
//        insertId.sROLLBACK_REASON_MSG = "PRODUCT UPDATE FAILED";
//        flag = true;
//    }
//    sqlDataReader.Close();
//}
//if (!flag)
//{
//    using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATECOLOR", connection, transaction))
//    {
//        sqlCommand.Parameters.Add("@biCOLORID", SqlDbType.BigInt).Value = ViewState["COLORID"] + ""; //(object)iCOLORID;
//        sqlCommand.Parameters.Add("@vCOLOR", SqlDbType.VarChar).Value = txtColor.Value.Trim(); // (object)sCOLOR;
//        sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + "";  //(object)insertId.iPRODID;
//        sqlCommand.CommandType = CommandType.StoredProcedure;
//        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//        if (sqlDataReader.HasRows)
//        {
//            while (sqlDataReader.Read())
//                ;
//        }
//        else
//        {
//            sqlDataReader.Close();
//            transaction.Rollback();
//            insertId.sROLLBACK_REASON_MSG = "COLOR UPDATE FAILED";
//            flag = true;
//        }
//        sqlDataReader.Close();
//    }
//}
//if (!flag)
//{
//    using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATESIZE", connection, transaction))
//    {
//        sqlCommand.Parameters.Add("@biSIZEID", SqlDbType.BigInt).Value = ViewState["SIZEID"] + ""; // (object)iSIZEID;
//        sqlCommand.Parameters.Add("@vSIZE", SqlDbType.VarChar).Value = txtSize.Value.Trim();  //(object)sSIZE;
//        sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + ""; // (object)insertId.iPRODID;
//        sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; // (object)iCATID;
//        sqlCommand.CommandType = CommandType.StoredProcedure;
//        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//        if (sqlDataReader.HasRows)
//        {
//            while (sqlDataReader.Read())
//                ;
//        }
//        else
//        {
//            sqlDataReader.Close();
//            transaction.Rollback();
//            insertId.sROLLBACK_REASON_MSG = "SIZE INSERT FAILED";
//            flag = true;
//        }
//        sqlDataReader.Close();
//    }
//}
//using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTPRODUCT", connection, transaction))
//{
//    sqlCommand.Parameters.Add("@nvPRODUCT", SqlDbType.NVarChar).Value = txtProduct.Value.Trim(); // (object)sPRODUCT;
//    sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim(); //(object)sDESCRIPTION;
//    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.Text.Trim(); // (object)iBRANDID;
//    sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = txtYear.Value.Trim(); // (object)sYEAR;
//    sqlCommand.CommandType = CommandType.StoredProcedure;
//    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//    if (sqlDataReader.HasRows)
//    {
//        while (sqlDataReader.Read())
//            insertId.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
//    }
//    else
//    {
//        sqlDataReader.Close();
//        transaction.Rollback();
//        insertId.sROLLBACK_REASON_MSG = "PRODUCT INSERT FAILED";
//        flag = true;
//    }
//    sqlDataReader.Close();
//}
//if (!flag)
//{
//    using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTCOLOR", connection, transaction))
//    {
//        sqlCommand.Parameters.Add("@vCOLOR", SqlDbType.VarChar).Value = txtColor.Value.Trim(); // (object)sCOLOR;
//        sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = insertId.iPRODID;
//        sqlCommand.CommandType = CommandType.StoredProcedure;
//        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//        if (sqlDataReader.HasRows)
//        {
//            while (sqlDataReader.Read())
//                insertId.iCOLORID = long.Parse(sqlDataReader["COLORID"].ToString());
//        }
//        else
//        {
//            sqlDataReader.Close();
//            transaction.Rollback();
//            insertId.sROLLBACK_REASON_MSG = "COLOR INSERT FAILED";
//            flag = true;
//        }
//        sqlDataReader.Close();
//    }
//}
//if (!flag)
//{
//    using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTSIZE", connection, transaction))
//    {
//        sqlCommand.Parameters.Add("@vSIZE", SqlDbType.VarChar).Value = txtSize.Value.Trim(); // (object)sSIZE;
//        sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = insertId.iPRODID;
//        sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //iCATID;
//        sqlCommand.CommandType = CommandType.StoredProcedure;
//        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
//        if (sqlDataReader.HasRows)
//        {
//            while (sqlDataReader.Read())
//                insertId.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
//        }
//        else
//        {
//            sqlDataReader.Close();
//            transaction.Rollback();
//            insertId.sROLLBACK_REASON_MSG = "SIZE INSERT FAILED";
//            flag = true;
//        }
//        sqlDataReader.Close();
//    }
//}