﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eSHOPUpload
{
    public partial class Image : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Guid guIMAGEGUIDID = Guid.Parse(Request.QueryString["X"] + "");
            cSQLDataImage cImage = new cSQLDataImage();            
            Response.ContentType = "image/jpeg";
            Response.BinaryWrite(cImage.SP_IMAGEBYID(guIMAGEGUIDID));
        }

    }
}