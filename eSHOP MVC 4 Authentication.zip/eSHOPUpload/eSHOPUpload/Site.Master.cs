﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
    public partial class SiteMaster : MasterPage
    {
        string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            MainContent.Visible = false;
            divLogon.Visible = true;
            if (Session["LOGIN"] + "" == "Y")
            {
                MainContent.Visible = true;
                divLogon.Visible = false;
            }
        }

        protected void btnLogon_Click(object sender, EventArgs e)
        {
            //Check for 1 username password
            //No username password insert one
            //Change Username and Password in WEB CONFIG. Only allows one username and password. Inserts from WebConfig if doesnt exist.
            SqlConnection conB = new SqlConnection(sConnection);
            SqlCommand cmdB = new SqlCommand("SP_LOGONPRODINSERT", conB);
            cmdB.Parameters.Add("@nvUSERNAME", SqlDbType.NVarChar, 150).Value = Crypto.Encrypt(System.Configuration.ConfigurationManager.AppSettings["Username"].ToString());
            cmdB.Parameters.Add("@nvPASSWORD", SqlDbType.NVarChar, 150).Value = Crypto.Encrypt(System.Configuration.ConfigurationManager.AppSettings["Password"].ToString());
            cmdB.CommandType = CommandType.StoredProcedure;
            conB.Open();
            cmdB.ExecuteNonQuery();
            conB.Close();
            

            SqlConnection con = new SqlConnection(sConnection);
            SqlCommand cmd = new SqlCommand("SP_LOGONPRODUPLOAD", con);
            cmd.Parameters.Add("@nvUSERNAME", SqlDbType.VarChar, 250).Value = Crypto.Encrypt(txtUsername.Value.Trim());
            cmd.Parameters.Add("@nvPASSWORD", SqlDbType.VarChar, 250).Value = Crypto.Encrypt(txtPassword.Value.Trim());
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0][0].ToString() != "0")
                {
                    Session["LOGONID"] = dt.Rows[0][0].ToString();
                    MainContent.Visible = true;
                    divLogon.Visible = false;
                    Session["LOGIN"] = "Y";
                }
                else
                {
                    Session["LOGIN"] = "N";
                    divLogon.Visible = true;
                }
            }

            //setup system table
            SqlConnection conCheckSystem = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmdCheckSystem = new SqlCommand("SP_INSERTSYSTEM", conCheckSystem);
                cmdCheckSystem.CommandType = CommandType.StoredProcedure;
                conCheckSystem.Open();
                cmdCheckSystem.ExecuteNonQuery();
                conCheckSystem.Close();
            }
            catch (Exception ex)
            {
                LogError.InsertError("SiteMaster.aspx", "btnLogon_Click", ex.ToString(), "SP_INSERTSYSTEM");
            }
            finally
            {
                con.Close();
            }
        }

    }
}