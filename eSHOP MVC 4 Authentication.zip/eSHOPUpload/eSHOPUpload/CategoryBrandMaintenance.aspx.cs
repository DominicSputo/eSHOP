﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
    public partial class CategoryBrandMaintenance : Page
    {
        string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection(sConnection);
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_CATEGORY", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    DataTable dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    ddlCategoryBrand.DataSource = dt;
                    ddlCategoryBrand.DataValueField = "CATID";
                    ddlCategoryBrand.DataTextField = "CATEGORY";
                    ddlCategoryBrand.DataBind();
                    ddlCategoryUpdate.DataSource = dt;
                    ddlCategoryUpdate.DataValueField = "CATID";
                    ddlCategoryUpdate.DataTextField = "CATEGORY";
                    ddlCategoryUpdate.DataBind();
                }
                catch (Exception ex)
                {
                    LogError.InsertError("CategoryBrandMaintenance.aspx", "Page_Load", ex.ToString(), "SP_CATEGORY");
                }
                finally
                {
                    con.Close();
                }

                SqlConnection conB = new SqlConnection(sConnection);
                try
                {
                    SqlCommand cmdB = new SqlCommand("SP_BRAND", conB);
                    cmdB.CommandType = CommandType.StoredProcedure;
                    conB.Open();
                    SqlDataReader dtrB = cmdB.ExecuteReader();
                    ddlBrandUpdate.DataSource = dtrB;
                    ddlBrandUpdate.DataValueField = "BRANDID";
                    ddlBrandUpdate.DataTextField = "BRAND";
                    ddlBrandUpdate.DataBind();
                }
                catch (Exception ex)
                {
                    LogError.InsertError("CategoryBrandMaintenance.aspx", "Page_Load", ex.ToString(), "SP_BRAND");
                }
                finally
                {
                    conB.Close();
                }





                //ADDCODE TO CHECK THE CHECKBOX FOR SHOWMENU AND SHOWCATEGORYTAB

                LoadCategoryMenu();
                LoadRepeaterCatBrand();
            }
        }

        public void LoadRepeaterCatBrand()
        {//done
            SqlConnection conCategoryBrand = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmdCategoryBrand = new SqlCommand("SELECT c.catid, b.brandid, c.category, b.brand FROM category c LEFT JOIN categorybrand cb ON cb.catid = c.catid LEFT JOIN BRAND b ON cb.brandid = b.brandid ORDER BY c.category", conCategoryBrand);
                cmdCategoryBrand.CommandType = CommandType.Text;
                conCategoryBrand.Open();
                SqlDataReader dtr = cmdCategoryBrand.ExecuteReader();
                rptCategoryBrand.DataSource = dtr;
                rptCategoryBrand.DataBind();
                conCategoryBrand.Close();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "LoadRepeaterCatBrand", ex.ToString(), "");
            }
            finally
            {
                conCategoryBrand.Close();
            }
        
        }

        protected void btnInsertCategory_Click(object sender, EventArgs e)
        {//done
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_INSERTCATEGORY", con);
                cmd.Parameters.Add("@vCATEGORY", SqlDbType.VarChar, 250).Value = txtCategory.Text;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                ddlCategoryBrand.DataSource = dt;
                ddlCategoryBrand.DataValueField = "CATID";
                ddlCategoryBrand.DataTextField = "CATEGORY";
                ddlCategoryBrand.DataBind();
                ddlCategoryUpdate.DataSource = dt;
                ddlCategoryUpdate.DataValueField = "CATID";
                ddlCategoryUpdate.DataTextField = "CATEGORY";
                ddlCategoryUpdate.DataBind();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnInsertCategory_Click", ex.ToString(), "SP_INSERTCATEGORY");
            }
            finally
            {
                con.Close();
            }
            LoadRepeaterCatBrand();
        }

        protected void btnInsertBrand_Click(object sender, EventArgs e)
        {//done
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_INSERTBRAND", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@vBRAND", SqlDbType.VarChar, 250).Value = txtBrand.Text;
                cmd.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategoryBrand.SelectedValue;
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                ddlBrandUpdate.DataSource = dtr;
                ddlBrandUpdate.DataValueField = "BRANDID";
                ddlBrandUpdate.DataTextField = "BRAND";
                ddlBrandUpdate.DataBind();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnInsertBrand_Click", ex.ToString(), "SP_INSERTBRAND");
            }
            finally
            {
                con.Close();
            }
            LoadRepeaterCatBrand();
        }


        protected void btnDeleteCategory_Click(object sender, EventArgs e)
        {//done
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_DELETECATEGORY", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategoryUpdate.SelectedValue;
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                if (dtr.HasRows)
                {
                    ddlBrandUpdate.DataSource = dtr;
                    ddlBrandUpdate.DataValueField = "BRANDID";
                    ddlBrandUpdate.DataTextField = "BRAND";
                    ddlBrandUpdate.DataBind();

                    if (dtr.NextResult())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(dtr);
                        ddlCategoryBrand.DataSource = dt;
                        ddlCategoryBrand.DataValueField = "CATID";
                        ddlCategoryBrand.DataTextField = "CATEGORY";
                        ddlCategoryBrand.DataBind();
                        ddlCategoryUpdate.DataSource = dt;
                        ddlCategoryUpdate.DataValueField = "CATID";
                        ddlCategoryUpdate.DataTextField = "CATEGORY";
                        ddlCategoryUpdate.DataBind();
                    }

                    if (dtr.NextResult())
                    {
                        while (dtr.Read())
                        {
                            if ((bool)dtr["ALREADYEXIST"])
                            {
                                lblError.Text = "Error: Cannot Delete Category. Product already exists with Category. Must change all product Category.";
                            }
                        }
                    }
                }
                else
                {
                    ddlCategoryUpdate.Items.Clear();
                    ddlCategoryBrand.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnDeleteCategory_Click", ex.ToString(), "SP_DELETECATEGORY");
            }
            finally
            {
                con.Close();
            }
            LoadRepeaterCatBrand();
        }

        protected void btnUpdateCategory_Click(object sender, EventArgs e)
        {//done
            SqlConnection conUpdate = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmdUpdate = new SqlCommand("SP_UPDATECATEGORY", conUpdate);
                cmdUpdate.CommandType = CommandType.StoredProcedure;
                cmdUpdate.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategoryUpdate.SelectedValue;
                cmdUpdate.Parameters.Add("@vCATEGORY", SqlDbType.VarChar, 250).Value = txtCategoryUpdate.Text;
                conUpdate.Open();
                DataTable dt = new DataTable();
                dt.Load(cmdUpdate.ExecuteReader());
                ddlCategoryBrand.DataSource = dt;
                ddlCategoryBrand.DataValueField = "CATID";
                ddlCategoryBrand.DataTextField = "CATEGORY";
                ddlCategoryBrand.DataBind();
                ddlCategoryUpdate.DataSource = dt;
                ddlCategoryUpdate.DataValueField = "CATID";
                ddlCategoryUpdate.DataTextField = "CATEGORY";
                ddlCategoryUpdate.DataBind();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnUpdateCategory_Click", ex.ToString(), "SP_UPDATECATEGORY");
            }
            finally
            {
                conUpdate.Close();
            }
            LoadRepeaterCatBrand();
        }

        protected void btnUpdateBrand_Click(object sender, EventArgs e)
        { //done
            SqlConnection conUpdate = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmdUpdate = new SqlCommand("SP_UPDATEBRAND", conUpdate);
                cmdUpdate.CommandType = CommandType.StoredProcedure;
                cmdUpdate.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrandUpdate.SelectedValue;
                cmdUpdate.Parameters.Add("@vBRAND", SqlDbType.VarChar).Value = txtBrandUpdate.Text;
                conUpdate.Open();
                DataTable dt = new DataTable();
                dt.Load(cmdUpdate.ExecuteReader());
                ddlBrandUpdate.DataSource = dt;
                ddlBrandUpdate.DataValueField = "BRANDID";
                ddlBrandUpdate.DataTextField = "BRAND";
                ddlBrandUpdate.DataBind();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnUpdateBrand_Click", ex.ToString(), "SP_UPDATEBRAND");
            }
            finally
            {
                conUpdate.Close();
            }
            LoadRepeaterCatBrand();
        }

        protected void rptCategoryBrand_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandArgument.ToString() != "" && e.CommandName != "")
            {
                SqlConnection con = new SqlConnection(sConnection);
                try
                {
                    SqlCommand cmd = new SqlCommand("SP_DELETEBRAND", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = e.CommandArgument.ToString();
                    cmd.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = e.CommandName;
                    con.Open();
                    SqlDataReader dtr = cmd.ExecuteReader();
                    ddlBrandUpdate.DataSource = dtr;
                    ddlBrandUpdate.DataValueField = "BRANDID";
                    ddlBrandUpdate.DataTextField = "BRAND";
                    ddlBrandUpdate.DataBind();

                    if (dtr.NextResult())
                    {
                        while (dtr.Read())
                        {
                            if ((bool)dtr["ALREADYEXIST"])
                            {
                                lblError.Text = "Error: Cannot Delete Brand. Product already exists with Brand. Must change all product brand.";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogError.InsertError("CategoryBrandMaintenance.aspx", "rptCategoryBrand_ItemCommand", ex.ToString(), "SP_DELETEBRAND");
                }
                finally
                {
                    con.Close();
                }                
                LoadRepeaterCatBrand();
            }
        }


        protected void btnSaveCategory_Click(object sender, EventArgs e)
        {
            foreach (RepeaterItem rptItem in rptShowCategory.Items)
            {
                HiddenField hdCATID = (HiddenField)rptItem.FindControl("hdCATID");
                CheckBox cbkCategoryMenu = (CheckBox)rptItem.FindControl("cbkCategoryMenu");
                CheckBox cbkCategoryTab = (CheckBox)rptItem.FindControl("cbkCategoryTab");
                SaveCategoryMenuAndTab(hdCATID.Value, cbkCategoryMenu.Checked, cbkCategoryTab.Checked);
            }

            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_UPDATESHOWMENU", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@bSHOWCATEGORYMENU", SqlDbType.Bit).Value = cbkShowMenu.Checked;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnSaveCategory_Click", ex.ToString(), "SP_UPDATESHOWMENU");
            }
            finally
            {
                con.Close();
            }
            
            try
            {
                SqlCommand cmd = new SqlCommand("SP_UPDATESHOWCATEGORYTAB", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@bSHOWCATEGORYTAB", SqlDbType.Bit).Value = cbkShowCategoryMenu.Checked;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "btnSaveCategory_Click", ex.ToString(), "SP_UPDATESHOWMENU");
            }
            finally
            {
                con.Close();
            }
        }

        public void SaveCategoryMenuAndTab(string sCATID, bool bCATMENU, bool bCATTAB)
        {
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_UPDATECATEGORYMENUTAB", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = sCATID;
                cmd.Parameters.Add("@bSHOWCATEGORYMENU", SqlDbType.Bit).Value = bCATMENU;
                cmd.Parameters.Add("@bSHOWCATEGORYTAB", SqlDbType.Bit).Value = bCATTAB;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance.aspx", "SaveCategoryMenuAndTab", ex.ToString(), "SP_UPDATECATEGORYMENUTAB");
            }
            finally
            {
                con.Close();
            }
        }

        public void LoadCategoryMenu()
        {
            SqlConnection con = new SqlConnection(sConnection);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_CATEGORYMENU", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                rptShowCategory.DataSource = dtr;
                rptShowCategory.DataBind();

                if (dtr.NextResult())
                {
                    while (dtr.Read())
                    {
                        cbkShowMenu.Checked = (bool)dtr["SHOWMENU"];
                    }
                }
            }
            catch (Exception ex)
            {
                LogError.InsertError("CategoryBrandMaintenance", "LoadCategoryMenu", ex.ToString(), "SP_CATEGORYMENU");
            }
            finally
            {
                con.Close();
            }
        }

        protected void rptShowCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox cbkCategoryMenu = (CheckBox)e.Item.FindControl("cbkCategoryMenu");
                CheckBox cbkCategoryTab = (CheckBox)e.Item.FindControl("cbkCategoryTab");
                cbkCategoryMenu.Checked = (bool)DataBinder.Eval(e.Item.DataItem, "SHOWCATEGORYMENU");
                cbkCategoryTab.Checked = (bool)DataBinder.Eval(e.Item.DataItem, "SHOWCATEGORYTAB");
            }
        }
    }
}


//protected void btnDeleteBrand_Click(object sender, EventArgs e)
//{//done
//    SqlConnection con = new SqlConnection(sConnection);
//    SqlCommand cmd = new SqlCommand("SP_DELETEBRAND", con);
//    cmd.CommandType = CommandType.StoredProcedure;
//    cmd.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrandUpdate.SelectedValue;
//    con.Open();
//    SqlDataReader dtr = cmd.ExecuteReader();
//    ddlBrandUpdate.DataSource = dtr;
//    ddlBrandUpdate.DataValueField = "BRANDID";
//    ddlBrandUpdate.DataTextField = "BRAND";
//    ddlBrandUpdate.DataBind();
//    con.Close();
//    LoadRepeaterCatBrand();
//}

//string sCommand = e.CommandName;
//if (sCommand == "UPDATE")
//{
//    SqlConnection conUpdate = new SqlConnection(sConnection);
//    SqlCommand cmdUpdate = new SqlCommand("SP_UPDATEBRAND", conUpdate);
//    cmdUpdate.CommandType = CommandType.StoredProcedure;
//    cmdUpdate.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ;
//    cmdUpdate.Parameters.Add("@vBRAND", SqlDbType.VarChar);
//}