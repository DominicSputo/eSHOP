﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
    public partial class Test : Page
    {
        string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_VIDEO", con);
                cmd.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = "100007";
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
        }


        protected void rptYouTube_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "UPDATE")
            {
                System.Web.UI.HtmlControls.HtmlInputControl txtYouTubeURL = (System.Web.UI.HtmlControls.HtmlInputControl)e.Item.FindControl("txtYouTubeURL");
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_UPDATEVIDEO", con);
                cmd.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = e.CommandArgument.ToString();
                cmd.Parameters.Add("@vURL", SqlDbType.BigInt).Value = txtYouTubeURL.Value.Trim();
                cmd.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = ViewState["INVENTORYID"] + "";
                cmd.Parameters.Add("@bYOUTUBE", SqlDbType.NVarChar).Value = true;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
            else
            {
                System.Web.UI.HtmlControls.HtmlInputControl txtYouTubeURL = (System.Web.UI.HtmlControls.HtmlInputControl)e.Item.FindControl("txtYouTubeURL");
                SqlConnection con = new SqlConnection(sConnection);
                SqlCommand cmd = new SqlCommand("SP_DELETEVIDEO", con);
                cmd.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = e.CommandArgument.ToString();
                cmd.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = ViewState["INVENTORYID"] + "";
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                rptYouTube.DataSource = dt;
                rptYouTube.DataBind();
                con.Close();
            }
        }
    }
}