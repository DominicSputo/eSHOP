﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace eSHOPUpload
{
    public class cSQLDataImage
    {
        public string sConnectionString = ConfigurationManager.ConnectionStrings["eSHOPIMAGE"].ConnectionString;
        
        /// <summary>
        /// Returns Byte Array of Image Data of specific image.
        /// </summary>
        /// <param name="guIMAGEGUIDID"></param>
        /// <returns></returns>
        public byte[] SP_IMAGEBYID(Guid guIMAGEGUIDID)
        {
            byte[] bytImage = null;
            SqlConnection connection = new SqlConnection(sConnectionString);
            try
            {
                SqlCommand command = new SqlCommand("SP_IMAGEBYID", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@uiIMAGEGUIDID", SqlDbType.UniqueIdentifier).Value = guIMAGEGUIDID;
                connection.Open();
                SqlDataReader dtr = command.ExecuteReader();
                while (dtr.Read())
                {
                    bytImage = (byte[])(dtr["imagedata"]);
                }
                connection.Close();
                return bytImage;
            }
            catch (SqlException ex)
            {
                LogError.InsertError("cSQLDataImage.cs", "SP_IMAGEBYID", ex.ToString(), "SP_IMAGEBYID");
            }
            finally
            {
                connection.Close();
            }
            return new byte[0];
        }
        
        /// <summary>
        /// Returns a List of IMAGEGUIDID.
        /// </summary>
        /// <param name="guINVENTORYGUIDID"></param>
        /// <param name="iINVENTORYID"></param>
        /// <returns></returns>
        public DataSet SP_IMAGEBYINV(Guid guINVENTORYGUIDID = new Guid(), Int64 iINVENTORYID = 0)
        {
            SqlConnection connection = new SqlConnection(sConnectionString);
            try
            {
                SqlCommand command = new SqlCommand("SP_IMAGEBYINV", connection);
                command.CommandType = CommandType.StoredProcedure;
                if (guINVENTORYGUIDID != new Guid())
                {
                    command.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = guINVENTORYGUIDID;
                }
                if (iINVENTORYID != 0)
                {
                    command.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = iINVENTORYID;
                }
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = command;
                DataSet ds = new DataSet();
                da.Fill(ds, "IMAGES");
                return ds;
            }
            catch (SqlException ex)
            {
                LogError.InsertError("cSQLDataImage.cs", "SP_IMAGEBYINV", ex.ToString(), "SP_IMAGEBYINV");
            }
            finally
            {
                connection.Close();
            }
            return new DataSet();
        }

        /// <summary>
        /// Set dHeight of image. Set dWidth of image. Set Min Width. If Image is over MinWidth no image resize happens. dMinWidth overrides dWidth. Set Min Height. If Image is over MinHeight no image resize happens. dMinHeight overrides dHeight
        /// </summary>
        /// <param name="bytIMAGEDATA"></param>
        /// <param name="guINVENTORYGUIDID"></param>
        /// <param name="iINVENTORYID"></param>
        /// <param name="bMAIN"></param>
        /// <param name="dHeight">Set dHeight of image</param>
        /// <param name="dWidth">Set dWidth of image</param>
        /// <param name="dMinWidth">Set Min Width. If Image is over MinWidth no image resize happens. dMinWidth overrides dWidth</param> 
        /// <param name="dMinHeight">Set Min Height. If Image is over MinHeight no image resize happens. dMinHeight overrides dHeight</param> 
        /// <param name="dMaxImageSizeMegaBytes">Sets the max mega bytes allowed</param> 
        /// <returns></returns>
        public Guid SP_INSERTIMAGE(byte[] bytIMAGEDATA, Guid guINVENTORYGUIDID = new Guid(), Int64 iINVENTORYID = 0,  bool bMAIN = false, 
            double dHeight = 0, double dWidth = 0, double dMinWidth = 0, double dMinHeight = 0, double dMaxImageSizeMegaBytes = 0)
        {
            bool bEnableImageResize = true; //only resize images that have height, width, min width or min height
            bool bMaxImageSizeForceImageResize = false;
            MemoryStream ms = new MemoryStream(bytIMAGEDATA);
            ImageResize ir = new ImageResize();
            ir.File = System.Drawing.Image.FromStream(ms);
            if (dMaxImageSizeMegaBytes > 0) //Set Max Image Size for Database
            {
                double dImageSizeMegaBytes = Math.Round(((bytIMAGEDATA.Length / 1024F) / 1024F), 2, MidpointRounding.AwayFromZero); //round 2 decimals back up 5 or greater
                if (dImageSizeMegaBytes > dMaxImageSizeMegaBytes) //resize image if max size reached
                {
                    bMaxImageSizeForceImageResize = true;
                }
            }
            if (dHeight > 0)
            {
                ir.Height = dHeight;
            }
            if (dMinHeight > 0) //they set min height
            {
                if (ir.File.Height >= dMinHeight) //min Height to upload. 
                {
                    if (bMaxImageSizeForceImageResize)
                    {
                        ir.Height = ir.File.Height; //max image size reached. use image original size
                    }
                    else // disable imageresize. keep image size & quality
                    {
                        bEnableImageResize = false;
                    }
                }
                else
                {
                    ir.Height = dMinHeight; //set minheight
                }
            }
            if (dWidth > 0) 
            {
                ir.Width = dWidth;
            }
            if (dMinWidth > 0) //they set min width
            {
                if (ir.File.Width >= dMinWidth) //min width to upload.
                {
                    if (bMaxImageSizeForceImageResize)
                    {
                        ir.Width = ir.File.Width; //max image size reached. use image original size
                    }
                    else // disable imageresize. keep image size & quality
                    {
                        bEnableImageResize = false;
                    }
                }
                else
                {
                    ir.Width = dMinWidth; //set minwidth
                }
            }
           
            if (bEnableImageResize)
            {
                using (var msNew = new MemoryStream())
                {
                    ir.GetImage().Save(msNew, System.Drawing.Imaging.ImageFormat.Jpeg);
                    bytIMAGEDATA = msNew.ToArray();
                }
            }

            Guid guIMAGEGUIDID = new Guid();
            SqlConnection connection = new SqlConnection(sConnectionString);
            try
            {
                SqlCommand command = new SqlCommand("SP_INSERTIMAGE", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@vbIMAGEDATA", SqlDbType.VarBinary).Value = bytIMAGEDATA;
                if (guINVENTORYGUIDID != new Guid())
                {
                    command.Parameters.Add("@uiINVENTORYGUIDID", SqlDbType.UniqueIdentifier).Value = guINVENTORYGUIDID;
                }
                if (iINVENTORYID != 0)
                {
                    command.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = iINVENTORYID;
                }
                command.Parameters.Add("@bMAIN", SqlDbType.Bit).Value = bMAIN;
                connection.Open();
                SqlDataReader dtr = command.ExecuteReader();
                while (dtr.Read())
                {
                    guIMAGEGUIDID = Guid.Parse(dtr["IMAGEGUIDID"].ToString());
                }
                connection.Close();
                return guIMAGEGUIDID;
            }
            catch (SqlException ex)
            {
                LogError.InsertError("cSQLDataImage.cs", "SP_INSERTIMAGE", ex.ToString(), "SP_IMAGEBYINV");
            }
            finally
            {
                connection.Close();
            }
            return new Guid();
        }

    }
}