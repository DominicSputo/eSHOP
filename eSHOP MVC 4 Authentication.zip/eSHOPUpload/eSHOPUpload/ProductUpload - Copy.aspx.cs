﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace eSHOPUpload
{
    public partial class ProductUpload : Page
    {
        string sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString; //@"Data Source=LAPTOP-ASH6NMMV\SQLEXPRESS;Initial Catalog=eSHOP;Integrated Security=True";

        public class InsertID
        {
            public long iCUSTID { get; set; }

            public long iPRODID { get; set; }

            public long iCOLORID { get; set; }

            public long iCATBRANDID { get; set; }

            public long iSIZEID { get; set; }

            public long iINVENTORYID { get; set; }

            public string sROLLBACK_REASON_MSG { get; set; }

            public bool bDUPLICATE { get; set; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (ViewState["INVENTORYID"] + "" == "")
            //{
            //    btnAddProduct.Visible = true;
            //    btnUpdateProduct.Visible = false;
            //}
            //else
            //{
            //    LoadVideo();
            //    btnUpdateProduct.Visible = true;
            //    btnAddProduct.Visible = false;
            //}
        }

        public void LoadVideo()
        {
            SqlConnection con = new SqlConnection(sConnection);
            SqlCommand cmd = new SqlCommand("SP_VIDEO", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            rptYouTube.DataSource = dt;
            rptYouTube.DataBind();
            con.Close();
        }

        public bool Insert()
        {
            lblError.Text = "";

            InsertID insertId = new InsertID();
            bool flag = false;
            using (SqlConnection connection = new SqlConnection(sConnection))
            {
                try
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTCATEGORYBRAND", connection, transaction))
                            {
                                sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //iCATID;
                                sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // iBRANDID;
                                sqlCommand.CommandType = CommandType.StoredProcedure;
                                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                if (sqlDataReader.HasRows)
                                {
                                    while (sqlDataReader.Read())
                                        insertId.iCATBRANDID = long.Parse(sqlDataReader["CATBRANDID"].ToString());
                                }
                                sqlDataReader.Close();
                            }
                            using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTPRODUCT", connection, transaction))
                            {
                                sqlCommand.Parameters.Add("@nvPRODUCT", SqlDbType.NVarChar).Value = txtProduct.Value.Trim(); // (object)sPRODUCT;
                                sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim(); //(object)sDESCRIPTION;
                                sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.Text.Trim(); // (object)iBRANDID;
                                sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = ddlYear.SelectedValue; // (object)sYEAR;
                                sqlCommand.CommandType = CommandType.StoredProcedure;
                                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                if (sqlDataReader.HasRows)
                                {
                                    while (sqlDataReader.Read())
                                        insertId.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
                                }
                                else
                                {
                                    sqlDataReader.Close();
                                    transaction.Rollback();
                                    insertId.sROLLBACK_REASON_MSG = "PRODUCT INSERT FAILED";
                                    flag = true;
                                }
                                sqlDataReader.Close();
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTCOLOR", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@vCOLOR", SqlDbType.VarChar).Value = txtColor.Value.Trim(); // (object)sCOLOR;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = insertId.iPRODID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                            insertId.iCOLORID = long.Parse(sqlDataReader["COLORID"].ToString());
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "COLOR INSERT FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTSIZE", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@vSIZE", SqlDbType.VarChar).Value = txtSize.Value.Trim(); // (object)sSIZE;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = insertId.iPRODID;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //iCATID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                            insertId.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "SIZE INSERT FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_INSERTINVENTORY", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // (object)iBRANDID;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = insertId.iPRODID;
                                    sqlCommand.Parameters.Add("@biID", SqlDbType.BigInt).Value = Session["LOGONID"] + ""; //(object)iCUSTID;
                                    sqlCommand.Parameters.Add("@biSIZEID", SqlDbType.BigInt).Value = insertId.iSIZEID;
                                    sqlCommand.Parameters.Add("@biCOLORID", SqlDbType.BigInt).Value = insertId.iCOLORID;
                                    sqlCommand.Parameters.Add("@biQUANTITY", SqlDbType.BigInt).Value = txtQuantity.Value.Trim(); // iQUANTITY;
                                    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit).Value = rblNew.Checked;
                                    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit).Value = rblUsed.Checked;
                                    sqlCommand.Parameters.Add("@dPRICE", SqlDbType.Decimal).Value = txtPrice.Value.Trim(); // dPRICE;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; // iCATID;
                                    //sqlCommand.Parameters.Add("@bPAYPAL", SqlDbType.Bit).Value = (object)bPAYPAL;
                                    //sqlCommand.Parameters.Add("@bCASHDIRECT", SqlDbType.Bit).Value = (object)bCASHDIRECT;
                                    //sqlCommand.Parameters.Add("@bAUTHNET", SqlDbType.Bit).Value = (object)bAUTHNET;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                        {
                                            insertId.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
                                            insertId.bDUPLICATE = bool.Parse(sqlDataReader["DUPLICATE"].ToString());
                                        }
                                    }
                                    else
                                    {
                                        flag = true;
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "INVENTORY INSERT FAILED";
                                    }
                                    sqlDataReader.Close();
                                    if (insertId.bDUPLICATE)
                                    {
                                        flag = true;
                                        insertId.sROLLBACK_REASON_MSG = "Failed! You have already entered this New Product with same size, color, and price. Please update your product from Manage Account.";
                                        transaction.Rollback();
                                    }
                                }
                            }
                            if (!flag)
                                transaction.Commit();
                            //return insertId;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            insertId.sROLLBACK_REASON_MSG = ex.ToString();
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connection.Close();
                }
                //return insertId;
            }
            if (insertId.sROLLBACK_REASON_MSG != "")
            {
                lblError.Text = insertId.sROLLBACK_REASON_MSG;
            }
            else
            {
                ViewState["CATBRANDID"] = insertId.iCATBRANDID;
                ViewState["PRODID"] = insertId.iPRODID;
                ViewState["COLORID"] = insertId.iCOLORID;
                ViewState["SIZEID"] = insertId.iSIZEID;
                ViewState["INVENTORYID"] = insertId.iINVENTORYID;
            }
            return flag;
        }

        public bool Update()
        {
            InsertID insertId = new InsertID();
            bool flag = false;
            using (SqlConnection connection = new SqlConnection(sConnection))
            {
                try
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATECATEGORYBRAND", connection, transaction))
                            {
                                sqlCommand.Parameters.Add("@biCATBRANDID", SqlDbType.BigInt).Value = ViewState["CATBRANDID"] + ""; //(object)iCATBRANDID;
                                sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; //(object)iCATID;
                                sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // (object)iBRANDID;
                                sqlCommand.CommandType = CommandType.StoredProcedure;
                                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                if (sqlDataReader.HasRows)
                                {
                                    //while (sqlDataReader.Read())
                                    //    ;
                                }
                                else
                                {
                                    sqlDataReader.Close();
                                    transaction.Rollback();
                                    insertId.sROLLBACK_REASON_MSG = "CATEGORY BRAND UPDATE FAILED";
                                    flag = true;
                                }
                                sqlDataReader.Close();
                            }
                            using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATEPRODUCT", connection, transaction))
                            {
                                sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + "";  //(object)iPRODID;
                                sqlCommand.Parameters.Add("@nvPRODUCT", SqlDbType.NVarChar).Value = txtProduct.Value.Trim(); //(object)sPRODUCT;
                                sqlCommand.Parameters.Add("@nvDESCRIPTION", SqlDbType.NVarChar).Value = txtDescription.Value.Trim(); //(object)sDESCRIPTION;
                                sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; //(object)iBRANDID;
                                sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = ddlYear.SelectedValue; //(object)sYEAR;
                                sqlCommand.CommandType = CommandType.StoredProcedure;
                                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                if (sqlDataReader.HasRows)
                                {
                                    while (sqlDataReader.Read())
                                        ;
                                }
                                else
                                {
                                    sqlDataReader.Close();
                                    transaction.Rollback();
                                    insertId.sROLLBACK_REASON_MSG = "PRODUCT UPDATE FAILED";
                                    flag = true;
                                }
                                sqlDataReader.Close();
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATECOLOR", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biCOLORID", SqlDbType.BigInt).Value = ViewState["COLORID"] + ""; //(object)iCOLORID;
                                    sqlCommand.Parameters.Add("@vCOLOR", SqlDbType.VarChar).Value = txtColor.Value.Trim(); // (object)sCOLOR;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + "";  //(object)insertId.iPRODID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                            ;
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "COLOR UPDATE FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATESIZE", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biSIZEID", SqlDbType.BigInt).Value = ViewState["SIZEID"] + ""; // (object)iSIZEID;
                                    sqlCommand.Parameters.Add("@vSIZE", SqlDbType.VarChar).Value = txtSize.Value.Trim();  //(object)sSIZE;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + ""; // (object)insertId.iPRODID;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; // (object)iCATID;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                            ;
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "SIZE INSERT FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                }
                            }
                            if (!flag)
                            {
                                using (SqlCommand sqlCommand = new SqlCommand("SP_UPDATEINVENTORY", connection, transaction))
                                {
                                    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = ViewState["INVENTORYID"] + ""; //(object)iINVENTORYID;
                                    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = ddlBrand.SelectedValue; // (object)iBRANDID;
                                    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = ViewState["PRODID"] + ""; // (object)insertId.iPRODID;
                                    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = Session["ID"] + ""; //(object)iCUSTID;
                                    sqlCommand.Parameters.Add("@biSIZEID", SqlDbType.BigInt).Value = ViewState["SIZEID"] + ""; // (object)insertId.iSIZEID;
                                    sqlCommand.Parameters.Add("@biCOLORID", SqlDbType.BigInt).Value = ViewState["COLORID"] + ""; //(object)insertId.iCOLORID;
                                    sqlCommand.Parameters.Add("@biQUANTITY", SqlDbType.BigInt).Value = txtQuantity.Value.Trim(); //(object)iQUANTITY;
                                    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit).Value = rblNew.Checked; //(object)bNEW;
                                    sqlCommand.Parameters.Add("@dPRICE", SqlDbType.Decimal).Value = txtPrice.Value.Trim(); //(object)dPRICE;
                                    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = ddlCategory.SelectedValue; // (object)iCATID;
                                    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit).Value = rblUsed.Checked; //(object)bUSED;
                                    //sqlCommand.Parameters.Add("@bPAYPAL", SqlDbType.Bit).Value = (object)bPAYPAL;
                                    //sqlCommand.Parameters.Add("@bCASHDIRECT", SqlDbType.Bit).Value = (object)bCASHDIRECT;
                                    //sqlCommand.Parameters.Add("@bAUTHNET", SqlDbType.Bit).Value = (object)bAUTHNET;
                                    sqlCommand.CommandType = CommandType.StoredProcedure;
                                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                                    if (sqlDataReader.HasRows)
                                    {
                                        while (sqlDataReader.Read())
                                            ;
                                    }
                                    else
                                    {
                                        sqlDataReader.Close();
                                        transaction.Rollback();
                                        insertId.sROLLBACK_REASON_MSG = "INVENTORY INSERT FAILED";
                                        flag = true;
                                    }
                                    sqlDataReader.Close();
                                    if (insertId.bDUPLICATE)
                                        flag = true;
                                }
                            }
                            if (insertId.bDUPLICATE)
                            {
                                insertId.sROLLBACK_REASON_MSG = "Warning!! This product has already been entered by you with the same product name, new condition, price, size and color.";
                                transaction.Rollback();
                            }
                            if (!flag)
                                transaction.Commit();
                            //return insertId;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            insertId.sROLLBACK_REASON_MSG = ex.ToString();
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connection.Close();
                }
                //return insertId;
                if (insertId.sROLLBACK_REASON_MSG != "")
                {
                    lblError.Text = insertId.sROLLBACK_REASON_MSG;
                }
            }
            return flag;
        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            {
                Insert();
            }           
        }

        protected void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" != "")
            {
                Update();
            }
        }

        protected void rptYouTube_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

        }

        protected void btnAddYouTube_Click(object sender, EventArgs e)
        {
            if (ViewState["INVENTORYID"] + "" == "")
            {
                if (Insert())
                {
                    InsertYouTube();
                }
            }
            else
            {
                if (Update())
                {
                    InsertYouTube();
                }
                InsertYouTube();
            }
        }

        public void InsertYouTube()
        {
            SqlConnection con = new SqlConnection(sConnection);
            SqlCommand cmd = new SqlCommand("SP_INSERTVIDEO", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@vURL", SqlDbType.NVarChar).Value = txtYouTube.Value.Trim();
            cmd.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = Session["INVENTORYID"] + "";
            cmd.Parameters.Add("@bYOUTUBE", SqlDbType.Bit).Value = true;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            rptYouTube.DataSource = dt;
            rptYouTube.DataBind();
            con.Close();
        }
    }
}