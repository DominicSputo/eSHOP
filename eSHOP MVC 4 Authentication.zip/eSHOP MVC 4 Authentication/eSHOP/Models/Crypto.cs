﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Configuration;

namespace eSHOP.Models
{
    public class Crypto
    {
        private string EncryptionKey = WebConfigurationManager.AppSettings["AES"].ToString();

        public string Encrypt(string clearText)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(this.EncryptionKey, new byte[13]
                {
          (byte) 69,
          (byte) 120,
          (byte) 57,
          (byte) 253,
          (byte) 39,
          (byte) 165,
          (byte) 209,
          (byte) 123,
          (byte) 235,
          (byte) 45,
          (byte) 115,
          (byte) 10,
          (byte) 101
                });
                aes.Key = rfc2898DeriveBytes.GetBytes(32);
                aes.IV = rfc2898DeriveBytes.GetBytes(16);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(bytes, 0, bytes.Length);
                        cryptoStream.Close();
                    }
                    clearText = Convert.ToBase64String(memoryStream.ToArray());
                }
            }
            return HttpUtility.UrlEncode(clearText);
        }

        public string Decrypt(string cipherText)
        {
            if (cipherText == null || cipherText == "")
                return "";
            cipherText = HttpUtility.UrlDecode(cipherText);
            byte[] buffer = Convert.FromBase64String(cipherText);
            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(this.EncryptionKey, new byte[13]
                {
          (byte) 69,
          (byte) 120,
          (byte) 57,
          (byte) 253,
          (byte) 39,
          (byte) 165,
          (byte) 209,
          (byte) 123,
          (byte) 235,
          (byte) 45,
          (byte) 115,
          (byte) 10,
          (byte) 101
                });
                aes.Key = rfc2898DeriveBytes.GetBytes(32);
                aes.IV = rfc2898DeriveBytes.GetBytes(16);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(buffer, 0, buffer.Length);
                        cryptoStream.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(memoryStream.ToArray());
                }
            }
            return cipherText;
        }
    }
}