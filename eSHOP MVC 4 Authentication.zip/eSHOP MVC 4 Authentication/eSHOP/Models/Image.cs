﻿using System;
namespace eSHOP.Models
{
    public class Image
    {
        public long iIMAGEID { get; set; }
        public string sURL { get; set; }
        public byte[] bytIMAGEDATA { get; set; }
        public bool bMAIN { get; set; }
        public Guid guINVENTORYGUIDID { get; set; }
        public Guid guIMAGEGUIDID { get; set; }
    }
}