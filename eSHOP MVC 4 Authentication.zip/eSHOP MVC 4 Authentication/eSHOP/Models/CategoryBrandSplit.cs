﻿namespace eSHOP.Models
{
    public class CategoryBrandSplit
    {
        public long iCATID { get; set; }

        public long iBRANDID { get; set; }
    }
}