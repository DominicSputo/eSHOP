﻿using System;

namespace eSHOP.Models
{
    public class Video
    {
        public long iVIDEOID { get; set; }

        public string sURL { get; set; }

        public Guid guINVENTORYGUIDID { get; set; }

        public bool bYOUTUBE { get; set; }
    }
}
