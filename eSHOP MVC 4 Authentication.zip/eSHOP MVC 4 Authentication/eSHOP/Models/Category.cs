﻿using System.Collections.Generic;

namespace eSHOP.Models
{
    public class Category
    {
        public long iCATID { get; set; }

        public string sCATEGORY { get; set; }

        public List<Brand> lstBRAND { get; set; }
    }
}