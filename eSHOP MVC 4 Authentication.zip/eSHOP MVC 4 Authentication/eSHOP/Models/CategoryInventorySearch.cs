﻿using System.Collections.Generic;

namespace eSHOP.Models
{
    public class CategoryInventorySearch
    {
        public CategoryBrand CategoryBrand { get; set; }

        public List<Inventory> lstInventory { get; set; }

        public List<SP_VIDEO_Result> Video { get; set; }

        public Pager Pager { get; set; }

        public List<SP_CUSTCART_Result> Cart { get; set; }
    }
}