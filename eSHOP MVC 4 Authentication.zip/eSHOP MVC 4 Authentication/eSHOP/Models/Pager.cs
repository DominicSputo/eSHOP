﻿namespace eSHOP.Models
{
    public class Pager
    {
        public Pager()
        {   //Default 3 Page buttons to show from the left and right side of the Active
            iNumberOfPageButtonMaxShow = 3;
        }
        public int iSearchResultCount { get; set; }

        public int iCurrentPageNumber { get; set; }

        public int iPageButtonCount { get; set; }

        public int iNumberProductPerPage { get; set; }

        public string sSortOrder { get; set; }

        /// <summary>
        /// Sets the Slider Price Max Value
        /// </summary>
        public string sSliderMaxValue { get; set; }
        /// <summary>
        /// Sets the Slider Price Min Value
        /// </summary>
        public string sSliderMinValue { get; set; }
        /// <summary>
        /// Sets the number of Page buttons to show from the left and right side of the Active
        /// </summary>
        public int iNumberOfPageButtonMaxShow { get; set; }
}
}