﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace eSHOP.Models
{
    public class Method
    {
        public static string URLEncode(string sValue)
        {
            return HttpUtility.UrlEncode(sValue);
        }

        public static string URLDecode(string sValue)
        {
            return HttpUtility.UrlDecode(sValue);
        }

        public static bool FTPUpload(ref HttpPostedFileBase hpf, ref string sFILENAME)
        {
            bool flag = true;
            try
            {
                Crypto crypto = new Crypto();
                FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create("ftp://kiteboardinglessonsstpete.com/images/product/" + sFILENAME);
                ftpWebRequest.Method = "STOR";
                ftpWebRequest.Credentials = (ICredentials)new NetworkCredential(crypto.Decrypt("wO6Ej7SCP1E7it8XC0p4sg%3d%3d"), crypto.Decrypt("e01eIEdXFw5i8FGmEkuTxrO3t1Dj89boUy2YGLELAO8%3d"));
                Stream inputStream = hpf.InputStream;
                Stream requestStream = ftpWebRequest.GetRequestStream();
                ftpWebRequest.ContentLength = inputStream.Length;
                int count1 = int.Parse(inputStream.Length.ToString());
                byte[] buffer = new byte[count1];
                int count2 = inputStream.Read(buffer, 0, count1);
                do
                {
                    requestStream.Write(buffer, 0, count2);
                    count2 = inputStream.Read(buffer, 0, count1);
                }
                while (count2 > 0);
                inputStream.Close();
                requestStream.Close();
                FtpWebResponse ftpWebResponse = (FtpWebResponse)ftpWebRequest.GetResponse();
            }
            catch (Exception ex)
            {
                flag = false;
            }
            return flag;
        }

        public static bool FTPDelete(ref string URL)
        {
            bool flag = true;
            try
            {
                Crypto crypto = new Crypto();
                FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create("ftp://kiteboardinglessonsstpete.com/images/product/" + Path.GetFileName(URL));
                ftpWebRequest.Method = "DELE";
                ftpWebRequest.Credentials = (ICredentials)new NetworkCredential(crypto.Decrypt("FDyB0Xg37RTLckGjXaBLig%3d%3d"), crypto.Decrypt("BG5oC6UiE9bHNNakdsb%2bGnSveP51KnvSRCrrIAaoOV4%3d"));
                ftpWebRequest.GetResponse().Close();
            }
            catch
            {
                flag = false;
            }
            return flag;
        }

        //public static long GetID(string sViewStateValue, HttpSessionStateBase Session, string Key)
        //{
        //    long num = Method.ParseLong(string.Concat(Session[Key]));
        //    if (num == 0L)
        //    {
        //        num = new E().GetID(Key, sViewStateValue);
        //        Session[Key] = (object)num;
        //    }
        //    return num;
        //}

        //public static int iImageCount(ref List<ImageURL> lstImageURL)
        //{
        //    if (lstImageURL == null)
        //        return 0;
        //    return lstImageURL.Count<ImageURL>();
        //}

        //public static int iProductCount(ref List<Product> lstProduct)
        //{
        //    if (lstProduct == null)
        //        return 0;
        //    return lstProduct.Count<Product>();
        //}

        public static bool ImageFileDelete(string sFile)
        {
            bool flag = true;
            try
            {
                System.IO.File.Delete(sFile);
            }
            catch
            {
                flag = false;
            }
            return flag;
        }

        public static string INITCAP(string sValue)
        {
            if (sValue == null)
                return "";
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(sValue.ToLower());
        }

        public static string WildCard(string sValue)
        {
            if (sValue != null && sValue != "")
                return "%" + sValue.Trim().ToUpper().Replace(' ', '%') + "%";
            return "";
        }

        public static void AssignLongVal(string sValue, out long iValue)
        {
            if (long.TryParse(sValue, out iValue))
                return;
            iValue = 0L;
        }

        public static long ParseInt64(string sValue)
        {
            long result;
            if (!long.TryParse(sValue, out result))
                result = 0L;
            return result;
        }

        public static bool ParseBool(string sValue)
        {
            bool result;
            if (!bool.TryParse(sValue, out result))
                result = false;
            return result;
        }

        public static Decimal ParseDecimal(string sValue)
        {
            Decimal result;
            if (!Decimal.TryParse(sValue, out result))
                result = new Decimal(0);
            return result;
        }

        public static long ParseLong(string sValue)
        {
            long result;
            if (!long.TryParse(sValue, out result))
                result = 0L;
            return result;
        }

        public static void AssignBoolVal(string sValue, out bool bValue)
        {
            if (bool.TryParse(sValue, out bValue))
                return;
            bValue = false;
        }

        public static void AssignDecimalVal(string sValue, out Decimal dValue)
        {
            if (Decimal.TryParse(sValue, out dValue))
                return;
            dValue = new Decimal(0);
        }

        public static void AssignIntVal(string sValue, out int iValue)
        {
            if (int.TryParse(sValue, out iValue))
                return;
            iValue = 0;
        }

        public static void TrimUpper(ref string sValue)
        {
            sValue = sValue.Trim().ToUpper();
        }

        public string YouTube(string sURL)
        {
            return "https://www.youtube.com/embed/" + sURL;
        }

        public static void YouTubeToVideoID(ref string sURL)
        {
            if (sURL.Contains("http://www.youtube.com/embed/"))
            {
                sURL = sURL.Replace("http://www.youtube.com/embed/", "").Substring(0, 11);
            }
            else
            {
                if (!sURL.Contains("https://www.youtube.com/watch?v="))
                    return;
                sURL = sURL.Replace("https://www.youtube.com/watch?v=", "").Substring(0, 11);
            }
        }

        public static string LocalHostImageTest(string sURL)
        {
            return sURL;
        }

        public static void SliderPrice(string sPRICERANGE, out Decimal dPriceStart, out Decimal dPriceEnd)
        {
            string[] strArray = sPRICERANGE.Split(',');
            if (!Decimal.TryParse(strArray[0].ToString(), out dPriceStart))
                dPriceStart = new Decimal(0);
            if (Decimal.TryParse(strArray[1].ToString(), out dPriceEnd))
                return;
            dPriceEnd = new Decimal(2000);
        }

        public static void NEWUSED(string sNEWUSED, out bool bNEW, out bool bUSED)
        {
            if (sNEWUSED == "NU")
            {
                bNEW = true;
                bUSED = true;
            }
            else if (sNEWUSED == "N")
            {
                bNEW = true;
                bUSED = false;
            }
            else
            {
                bNEW = false;
                bUSED = true;
            }
        }

        public static List<CategoryBrandSplit> LoadCategoryBrandSplit(string sCATEGORYBRAND)
        {
            List<CategoryBrandSplit> source = new List<CategoryBrandSplit>();
            try
            {
                //string str1 = sCATEGORYBRAND;
                char[] chArray1 = new char[1] { '|' };
                foreach (string str2 in sCATEGORYBRAND.Split(chArray1))
                {
                    char[] chArray2 = new char[1] { ',' };
                    string[] strArray = str2.Split(chArray2);
                    long iValue1;
                    Method.AssignLongVal(strArray[0] ?? "", out iValue1);
                    long iValue2;
                    Method.AssignLongVal(strArray[1] ?? "", out iValue2);
                    if (iValue1 != 0L && iValue2 != 0L)
                        source.Add(new CategoryBrandSplit()
                        {
                            iCATID = iValue1,
                            iBRANDID = iValue2
                        });
                }
            }
            catch
            {
            }
            return source.OrderBy<CategoryBrandSplit, long>((Func<CategoryBrandSplit, long>)(cb => cb.iCATID)).ThenBy<CategoryBrandSplit, long>((Func<CategoryBrandSplit, long>)(cb => cb.iBRANDID)).ToList<CategoryBrandSplit>();
        }

        public static void LoadBrandSplit(string sBRAND, out IEnumerable<long> sarBRAND)
        {
            try
            {
                sarBRAND = (IEnumerable<long>)Array.ConvertAll<string, long>(sBRAND.Split('|'), new Converter<string, long>(long.Parse));
            }
            catch
            {
                sarBRAND = (IEnumerable<long>)null;
            }
        }

        public static int CountInt64Array(ref IEnumerable<long> iValue)
        {
            try
            {
                return iValue.Count<long>();
            }
            catch
            {
            }
            return 0;
        }

        public static string SQLCategoryBrand(List<CategoryBrandSplit> lstCategoryBrand)
        {
            System.Text.StringBuilder sbr = new System.Text.StringBuilder();
            int iCnt = lstCategoryBrand.Count();
            int iIndex = 1;
            foreach (var item in lstCategoryBrand)
            {
                if (iCnt == 1) //one value
                {
                    sbr.Append(" (i.catid = " + item.iCATID + " AND i.brandid = " + item.iBRANDID + ") AND ");
                    break;
                }

                if (iIndex == 1) //first value
                {
                    sbr.Append(" ((i.catid = " + item.iCATID + " AND i.brandid = " + item.iBRANDID + ") OR ");
                    //sbr.Append(" i.brandid IN (" + item + ", ");
                }
                else if (iCnt == iIndex) //max/last value
                {
                    sbr.Append(" (i.catid = " + item.iCATID + " AND i.brandid = " + item.iBRANDID + ")) AND ");
                    //sbr.Append(" " + item + ") AND ");
                }
                else //middle values
                {
                    sbr.Append(" (i.catid = " + item.iCATID + " AND i.brandid = " + item.iBRANDID + ") OR ");
                    //sbr.Append(" " + item + ", ");
                }
                iIndex = iIndex + 1;
            }
            return sbr.ToString();
        }

        public static string SQLBrand(IEnumerable<long> iBRANDID)
        {
            System.Text.StringBuilder sbr = new System.Text.StringBuilder();
            int iCnt = iBRANDID.Count();
            int iIndex = 1;
            foreach (var item in iBRANDID)
            {
                if (iCnt == 1) //one value
                {
                    sbr.Append(" i.brandid = " + item + " AND ");
                    break;
                }

                if (iIndex == 1) //first value
                {
                    sbr.Append(" i.brandid IN (" + item + ", ");
                }
                else if (iCnt == iIndex) //max/last value
                {
                    sbr.Append(" " + item + ") AND ");
                }
                else //middle values
                {
                    sbr.Append(" " + item + ", ");
                }
                iIndex = iIndex + 1;
            }
            return sbr.ToString();
        }

        public static int PageButtonCount(int iSearchResultCount, int iNumberProductPerPage)
        {
            Decimal d = (Decimal)iSearchResultCount / (Decimal)iNumberProductPerPage;
            if (d.ToString().Contains<char>('.'))
                return int.Parse(Decimal.Add(Math.Truncate(d), 1).ToString()); //return int.Parse(Decimal.op_Increment(Math.Truncate(d)).ToString()); //WARNING CHANGED THIS!!!
            return int.Parse(Math.Truncate(d).ToString());
        }

        public static int PageIndexPositive(int iIndex)
        {
            if (iIndex <= 0)
                return 1;
            return iIndex;
        }

        public static int TotalPageButtonCount(int iTOTALRESULTCOUNT, int iPAGESIZE)
        {
            if (iTOTALRESULTCOUNT > 0)
            {
                decimal dTotalPageButtonCount = decimal.Parse(iTOTALRESULTCOUNT.ToString()) / decimal.Parse(iPAGESIZE.ToString());
                int iT = iTOTALRESULTCOUNT / iPAGESIZE;
                if (dTotalPageButtonCount > decimal.Parse(iT.ToString()))
                {
                    return iT + 1;
                }
                return iT;
            }
            else
            {
                return 0;
            }
            
        }

        public static int PageIndexMaxCount(int iCurrentPageNumber, int iPageButtonCount, int iNumberOfPageButtonMaxShow)
        {
            if (iCurrentPageNumber + iNumberOfPageButtonMaxShow <= iPageButtonCount)
                return iCurrentPageNumber + iNumberOfPageButtonMaxShow;
            return iPageButtonCount;
        }

        public static string PageNumberSelected(int iNumberProductPerPage, int iPage)
        {
            return iNumberProductPerPage == iPage ? "selected=\"selected\"" : "";
        }

        public static string SortSelected(string sSORT, string sSelectValue)
        {
            return sSORT == sSelectValue ? "selected=\"selected\"" : "";
        }

        public static void DefaultNullFilterSearchParam(ref string PAGENUMBER, ref string SORT, ref string NUMBERPERPAGE)
        {
            if (PAGENUMBER == null)
                PAGENUMBER = "1";
            if (SORT == null)
                SORT = "LowToHigh";
            if (NUMBERPERPAGE != null)
                return;
            NUMBERPERPAGE = "2";
        }

        public static string MainChecked(bool bMAIN)
        {
            return bMAIN ? "checked=\"checked\"" : "";
        }

        public static string Selected(string sValue1, string sValue2)
        {
            return sValue1 == sValue2 ? "selected=\"selected\"" : "";
        }
    }
}