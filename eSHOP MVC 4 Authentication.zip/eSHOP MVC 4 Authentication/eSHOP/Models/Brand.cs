﻿namespace eSHOP.Models
{
    public class Brand
    {
        public long iBRANDID { get; set; }

        public string sBRAND { get; set; }

        public string sTotalCount { get; set; }
    }
}
