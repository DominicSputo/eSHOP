﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace eSHOP.Models
{
    public class SQLData
    {
        private string sCon = ConfigurationManager.ConnectionStrings["eSHOP"].ConnectionString;
        private static string sConLogError = ConfigurationManager.ConnectionStrings["eSHOPERROR"].ConnectionString;

        public void LoadCategoryInventorySearch(ref CategoryInventorySearch cCIS, string sSEARCH, string sCATEGORYBRAND, string sBRANDID, string sNEWUSED, string sPRICERANGE, int iPAGESIZE, int iPAGENUMBER, string sSORT = "productname ASC") //int iCurrentPageNumber = 1, int iPageButtonCount = 6
        {
            List<CategoryBrandSplit> lstCategoryBrand = Method.LoadCategoryBrandSplit(sCATEGORYBRAND);
            IEnumerable<long> iBRANDID;
            Method.LoadBrandSplit(sBRANDID, out iBRANDID);
            //bool bNEW;
            //bool bUSED;
            //Method.NEWUSED(NEWUSED, out bNEW, out bUSED);
            //Method.DefaultNullFilterSearchParam(ref PAGENUMBER, ref SORT, ref NUMBERPERPAGE);
            //Decimal dPriceStart;
            //Decimal dPriceEnd;
            //Method.SliderPrice(SLD, out dPriceStart, out dPriceEnd);
            //IEnumerable<long> iBRAND;
            //Method.LoadBrandSplit(BRAND, out iBRAND);
            
            switch (sSORT)
            {
                case "LowToHigh":
                    sSORT = " price asc ";
                    break;
                case "HighToLow":
                    sSORT = " price desc ";
                    break;
                case "ProductYear":
                    sSORT = " year desc ";
                    break;
                default:
                    sSORT = " productname ASC ";
                    break;
            }
            StringBuilder sbSQL3 = new StringBuilder("SELECT (MAX(i.price) + 2) AS SLIDERMAXVALUE, MIN(i.price) AS SLIDERMINVALUE FROM inventory i INNER JOIN image u ON i.inventoryguidid = u.inventoryguidid WHERE ");
            StringBuilder sbSQL2 = new StringBuilder("SELECT COUNT(i.inventoryid) AS TOTALRESULTCOUNT, MAX(i.price) AS SLIDERMAXVALUE FROM inventory i INNER JOIN image u ON i.inventoryguidid = u.inventoryguidid WHERE ");
            StringBuilder sbSQL = new StringBuilder("SELECT i.inventoryguidid, i.productname, i.color, i.year, i.size, i.quantity, i.new, i.price, u.imageguidid " +
            "FROM inventory i INNER JOIN image u ON i.inventoryguidid = u.inventoryguidid WHERE ");
            if (sSEARCH != "" || sCATEGORYBRAND != "" || sBRANDID != "" || sNEWUSED != "" || sPRICERANGE != "" || sSORT != "")
            {
                if (sSEARCH != "")
                {
                    sbSQL.Append(" i.productname LIKE @PRODUCTNAME AND ");
                    sbSQL2.Append(" i.productname LIKE @PRODUCTNAME AND ");
                    sbSQL3.Append(" i.productname LIKE @PRODUCTNAME AND ");
                }
                if (sCATEGORYBRAND != "")
                {
                    string sCATBRAND = Method.SQLCategoryBrand(lstCategoryBrand);
                    sbSQL.Append(sCATBRAND);
                    sbSQL2.Append(sCATBRAND);
                    sbSQL3.Append(sCATBRAND);
                    //sbSQL.Append(" i.catid = @CATID AND ");
                    //sbSQL2.Append(" i.catid = @CATID AND ");
                }
                if (sBRANDID != "")
                {
                    string sBRAND = Method.SQLBrand(iBRANDID);
                    sbSQL.Append(sBRAND);
                    sbSQL2.Append(sBRAND);
                    sbSQL3.Append(sBRAND);
                    //sbSQL.Append(" i.brandid = @BRANDID AND ");
                    //sbSQL2.Append(" i.brandid = @BRANDID AND ");
                }
                if (sNEWUSED != "" && sNEWUSED != "NU")
                {
                    sbSQL.Append(" i.new = @NEW AND i.new = @USED AND ");
                    sbSQL2.Append(" i.new = @NEW AND i.new = @USED AND ");
                    sbSQL3.Append(" i.new = @NEW AND i.new = @USED AND ");
                }
                if (sPRICERANGE != "")
                {
                    sbSQL.Append(" (i.price >= @PRICESTART AND i.price <= @PRICEEND) AND ");
                    sbSQL2.Append(" (i.price >= @PRICESTART AND i.price <= @PRICEEND) AND ");
                }
                sbSQL.Append(" u.main = 1 ORDER BY " + sSORT + " OFFSET @PAGESIZE *(@PAGENUMBER - 1) ROWS FETCH NEXT @PAGESIZE ROWS ONLY;");
                sbSQL2.Append(" u.main = 1;");
                sbSQL3.Append(" u.main = 1;");
            }
            else
            {
                sbSQL.Append(" u.main = 1 ORDER BY " + sSORT + " OFFSET @PAGESIZE *(@PAGENUMBER - 1) ROWS FETCH NEXT @PAGESIZE ROWS ONLY;");
                sbSQL2.Append(" u.main = 1;");
                sbSQL3.Append(" u.main = 1;");
            }
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                SqlCommand cmd = new SqlCommand(sbSQL.ToString() + sbSQL2.ToString() + sbSQL3.ToString(), con);
                if (sSEARCH != "")
                {
                    cmd.Parameters.Add("PRODUCTNAME", SqlDbType.VarChar).Value = "%" + sSEARCH + "%";
                }
                //if (iCATID > 0)
                //{
                //    cmd.Parameters.Add("CATID", SqlDbType.BigInt).Value = iCATID;
                //}
                //if (iBRANDID > 0)
                //{
                //    cmd.Parameters.Add("BRANDID", SqlDbType.BigInt).Value = iBRANDID;
                //}
                if (sNEWUSED != "" && sNEWUSED != "NU")
                {
                    bool bNEW;
                    bool bUSED;
                    Method.NEWUSED(sNEWUSED, out bNEW, out bUSED);
                    cmd.Parameters.Add("NEW", SqlDbType.Bit).Value = bNEW;
                    cmd.Parameters.Add("USED", SqlDbType.Bit).Value = bUSED;
                }
                if (sPRICERANGE != "")
                {
                    string[] sarPRICERANGE = sPRICERANGE.Split(',');
                    Decimal dPRICESTART, dPRICEEND;
                    if (!Decimal.TryParse(sarPRICERANGE[0].ToString(), out dPRICESTART))
                        dPRICESTART = 0;
                    if (!Decimal.TryParse(sarPRICERANGE[1].ToString(), out dPRICEEND))
                        dPRICEEND = 2000;
                    cmd.Parameters.Add("PRICESTART", SqlDbType.Decimal).Value = dPRICESTART;
                    cmd.Parameters.Add("PRICEEND", SqlDbType.Decimal).Value = dPRICEEND;
                }
                cmd.Parameters.Add("PAGESIZE", SqlDbType.Int).Value = iPAGESIZE;
                cmd.Parameters.Add("PAGENUMBER", SqlDbType.Int).Value = iPAGENUMBER;
                con.Open();
                List<Inventory> lstInventory = new List<Inventory>();
                int iTOTALRESULTCOUNT = 0;
                string sSliderMaxValue = "9999999";
                string sSliderMinValue = "0";
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                {
                    List<Image> lstImage = new List<Image>();
                    Inventory cInventory = new Inventory();
                    cInventory.guINVENTORYGUIDID = Guid.Parse(dtr["INVENTORYGUIDID"].ToString());
                    cInventory.sPRODUCTNAME = dtr["PRODUCTNAME"].ToString();
                    cInventory.sCOLOR = dtr["COLOR"].ToString();
                    cInventory.sYEAR = dtr["YEAR"].ToString();
                    cInventory.sSIZE = dtr["SIZE"].ToString();
                    cInventory.iQUANTITY = long.Parse(dtr["QUANTITY"].ToString());
                    cInventory.bNEW = (bool)dtr["NEW"];
                    cInventory.dPRICE = Decimal.Parse(dtr["PRICE"].ToString());
                    lstImage.Add(new Image() { guIMAGEGUIDID = Guid.Parse(dtr["IMAGEGUIDID"].ToString()) });
                    cInventory.lstIMAGEURL = lstImage;
                    lstInventory.Add(cInventory);
                }
                if (dtr.NextResult())
                {
                    while (dtr.Read())
                    {
                        iTOTALRESULTCOUNT = int.Parse(dtr["TOTALRESULTCOUNT"] + "");
                    }
                }
                if (dtr.NextResult())
                {
                    while (dtr.Read())
                    {
                        sSliderMaxValue = dtr["SLIDERMAXVALUE"] + "";
                        sSliderMinValue = dtr["SLIDERMINVALUE"] + "";
                    }
                }
                con.Close();
                if (sSliderMaxValue == sSliderMinValue)
                {
                    sSliderMaxValue = (decimal.Parse(sSliderMaxValue) + 1).ToString();
                }
                Pager cPager = new Pager()
                {
                    iCurrentPageNumber = iPAGENUMBER,
                    iNumberProductPerPage = iPAGESIZE,
                    iPageButtonCount = Method.TotalPageButtonCount(iTOTALRESULTCOUNT, iPAGESIZE),
                    sSliderMaxValue = sSliderMaxValue,
                    sSliderMinValue = sSliderMinValue,
                    iSearchResultCount = iTOTALRESULTCOUNT,
                    sSortOrder = sSORT
                };
                cCIS.lstInventory = lstInventory;
                cCIS.Pager = cPager;
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "LoadCategoryInventorySearch", ex.ToString(), "");
            }
            finally
            {
                con.Close();
            }
        }

        public void LoadIMAGE(Guid guIMAGEGUIDID, ref byte[] bytIMAGEDATA)
        {
            SqlConnection con = new SqlConnection(this.sCon);
            SqlCommand cmd = new SqlCommand("SP_IMAGEGUIDID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@uiIMAGEGUIDID", SqlDbType.UniqueIdentifier).Value = guIMAGEGUIDID;
            try
            {
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                {
                    bytIMAGEDATA = (byte[])dtr["IMAGEDATA"];
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "LoadIMAGE", ex.ToString(), "SP_IMAGEGUIDID");
            }
            finally
            {
                con.Close();
            }
        }

        public List<Brand> SP_BRAND()
        {
            List<Brand> lstBrand = new List<Brand>();
            SqlConnection con = new SqlConnection(this.sCon);
            SqlCommand cmd = new SqlCommand("SP_BRAND", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                    lstBrand.Add(new Brand()
                    {
                        iBRANDID = Method.ParseLong(dtr["BRANDID"].ToString()),
                        sBRAND = dtr["BRAND"].ToString()
                    });
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "SP_BRAND", ex.ToString(), "SP_BRAND");
            }
            finally
            {
                con.Close();
            }
            return lstBrand;
        }

        public List<Category> SP_CATEGORY()
        {
            List<Category> lstCategory = new List<Category>();
            SqlConnection con = new SqlConnection(this.sCon);
            SqlCommand cmd = new SqlCommand("SP_CATEGORY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                    lstCategory.Add(new Category()
                    {
                        iCATID = Method.ParseLong(dtr["CATID"].ToString()),
                        sCATEGORY = dtr["CATEGORY"].ToString()
                    });
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "SP_CATEGORY", ex.ToString(), "SP_CATEGORY");
            }
            finally
            {
                con.Close();
            }
            return lstCategory;
        }

        public List<Brand> SP_BRANDCOUNT()
        {
            List<Brand> lstBrand = new List<Brand>();
            SqlConnection con = new SqlConnection(sCon);
            SqlCommand cmd = new SqlCommand("SP_BRANDCOUNT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                    lstBrand.Add(new Brand()
                    {
                        iBRANDID = long.Parse(dtr["BRANDID"].ToString()),
                        sBRAND = dtr["BRAND"].ToString(),
                        sTotalCount = dtr["BRANDTOTAL"].ToString()
                    });
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "SP_BRANDCOUNT", ex.ToString(), "SP_BRANDCOUNT");
            }
            finally
            {
                con.Close();
            }
            return lstBrand;
        }

        public List<Category> SP_CATEGORY_BRAND()
        {
            List<Brand> lstBrand = new List<Brand>();
            List<Category> lstCategory = new List<Category>();
            Category cCat = new Category();
            StringBuilder sbCat = new StringBuilder();
            bool flag = false;
            SqlConnection con = new SqlConnection(this.sCon);
            SqlCommand cmd = new SqlCommand("SP_CATEGORY_BRAND", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                con.Open();
                SqlDataReader dtr = cmd.ExecuteReader();
                while (dtr.Read())
                {
                    if (!flag)
                    {
                        sbCat.Append(dtr["CATEGORY"].ToString());
                        cCat.iCATID = long.Parse(dtr["CATID"].ToString());
                        cCat.sCATEGORY = dtr["CATEGORY"].ToString();
                        flag = true;
                    }
                    if (sbCat.ToString() != dtr["CATEGORY"].ToString())
                    {
                        cCat.lstBRAND = lstBrand;
                        lstCategory.Add(cCat);
                        sbCat.Clear();
                        lstBrand = new List<Brand>();
                        cCat = new Category();
                        sbCat.Append(dtr["CATEGORY"].ToString());
                        cCat.iCATID = long.Parse(dtr["CATID"].ToString());
                        cCat.sCATEGORY = dtr["CATEGORY"].ToString();
                    }
                    lstBrand.Add(new Brand()
                    {
                        iBRANDID = long.Parse(dtr["BRANDID"].ToString()),
                        sBRAND = dtr["BRAND"].ToString()
                    });
                }
            }
            catch (Exception ex)
            {
                Error(true, false, "SQLData.cs", "SP_CATEGORY_BRAND", ex.ToString(), "SP_CATEGORY_BRAND");
            }
            finally
            {
                con.Close();
            }
            if (lstBrand.Count >= 1)
            {
                cCat.lstBRAND = lstBrand;
                lstCategory.Add(cCat);
            }
            return lstCategory;
        }

        public static void Error(bool bASPNET, bool bAJAX, string sPage, string sMethod, string sError, string sProcedureName)
        {
            SqlConnection con = new SqlConnection(sConLogError);
            try
            {
                SqlCommand cmd = new SqlCommand("SP_INSERTERROR", con);
                cmd.Parameters.Add("@bASPNET", SqlDbType.Bit).Value = bASPNET;
                cmd.Parameters.Add("@bAJAX", SqlDbType.Bit).Value = bAJAX;
                cmd.Parameters.Add("@nvERRORMSG", SqlDbType.NVarChar).Value = sError;
                cmd.Parameters.Add("@nvPAGE", SqlDbType.NVarChar).Value = sPage;
                cmd.Parameters.Add("@nvMETHOD", SqlDbType.NVarChar).Value = sMethod;
                cmd.Parameters.Add("@nvPROCEDURENAME", SqlDbType.NVarChar).Value = sProcedureName;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                con.Close();
            }
        }

        //        string sql = "SELECT empSalary from employee where salary = @salary";

        //using (SqlConnection connection = new SqlConnection(/* connection info */))
        //using (SqlCommand command = new SqlCommand(sql, connection))
        //{
        //    var salaryParam = new SqlParameter("salary", SqlDbType.Money);
        //    salaryParam.Value = txtMoney.Text;

        //    command.Parameters.Add(salaryParam);
        //    var results = command.ExecuteReader();
        //}

        //public List<Inventory> Search(long iCATID, long iBRANDID, string sNEWUSED, string sPRICERANGE)
        //{
        //    string[] strArray = sPRICERANGE.Split(',');
        //    bool flag1 = false;
        //    List<Image> imageUrlList = new List<Image>();
        //    List<Inventory> inventorySearchList = new List<Inventory>();
        //    StringBuilder stringBuilder = new StringBuilder();
        //    Decimal result1;
        //    if (!Decimal.TryParse(strArray[0].ToString(), out result1))
        //        result1 = new Decimal(0);
        //    Decimal result2;
        //    if (!Decimal.TryParse(strArray[1].ToString(), out result2))
        //        result2 = new Decimal(2000);
        //    bool bNEW;
        //    bool bUSED;
        //    Method.NEWUSED(sNEWUSED, out bNEW, out bUSED);
        //    Inventory inventorySearch = new Inventory();
        //    bool flag2 = false;
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INVENTORYSEARCH", connection);
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt);
        //    sqlCommand.Parameters["@biCATID"].Value = (object)iCATID;
        //    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt);
        //    sqlCommand.Parameters["@biBRANDID"].Value = (object)iBRANDID;
        //    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit);
        //    sqlCommand.Parameters["@bNEW"].Value = (object)bNEW;
        //    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit);
        //    sqlCommand.Parameters["@bUSED"].Value = (object)bUSED;
        //    sqlCommand.Parameters.Add("@dPRICESTART", SqlDbType.Decimal);
        //    sqlCommand.Parameters["@dPRICESTART"].Value = (object)result1;
        //    sqlCommand.Parameters.Add("@dPRICEEND", SqlDbType.Decimal);
        //    sqlCommand.Parameters["@dPRICEEND"].Value = (object)result2;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        while (sqlDataReader.Read())
        //        {
        //            if (!flag2)
        //            {
        //                stringBuilder.Append(sqlDataReader["INVENTORYID"].ToString());
        //                if (!(stringBuilder.ToString() == "0") && !(sqlDataReader["QUANTITY"].ToString() == "0"))
        //                {
        //                    inventorySearch.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
        //                    inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                    inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                    inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                    inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                    inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                    inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                    inventorySearch.iBRANDID = long.Parse(sqlDataReader["BRANDID"].ToString());
        //                    inventorySearch.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
        //                    inventorySearch.iCUSTID = long.Parse(sqlDataReader["CUSTID"].ToString());
        //                    inventorySearch.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
        //                    inventorySearch.iQUANTITY = long.Parse(sqlDataReader["QUANTITY"].ToString());
        //                    inventorySearch.bNEW = (bool)sqlDataReader["NEW"];
        //                    inventorySearch.bUSED = (bool)sqlDataReader["USED"];
        //                    inventorySearch.dPRICE = Decimal.Parse(sqlDataReader["PRICE"].ToString());
        //                    inventorySearch.iCATID = long.Parse(sqlDataReader["CATID"].ToString());
        //                    flag2 = true;
        //                }
        //                else
        //                    break;
        //            }
        //            if (stringBuilder.ToString() != sqlDataReader["INVENTORYID"].ToString())
        //            {
        //                inventorySearch.lstIMAGEURL = imageUrlList;
        //                inventorySearchList.Add(inventorySearch);
        //                stringBuilder.Clear();
        //                imageUrlList = new List<Image>();
        //                inventorySearch = new Inventory();
        //                stringBuilder.Append(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                inventorySearch.iBRANDID = long.Parse(sqlDataReader["BRANDID"].ToString());
        //                inventorySearch.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
        //                inventorySearch.iCUSTID = long.Parse(sqlDataReader["CUSTID"].ToString());
        //                inventorySearch.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
        //                inventorySearch.iQUANTITY = long.Parse(sqlDataReader["QUANTITY"].ToString());
        //                inventorySearch.bNEW = (bool)sqlDataReader["NEW"];
        //                inventorySearch.bUSED = (bool)sqlDataReader["USED"];
        //                inventorySearch.dPRICE = Decimal.Parse(sqlDataReader["PRICE"].ToString());
        //                inventorySearch.iCATID = long.Parse(sqlDataReader["CATID"].ToString());
        //                flag1 = true;
        //            }
        //            imageUrlList.Add(new Image()
        //            {
        //                iIMAGEID = long.Parse(sqlDataReader["IMAGEID"].ToString()),
        //                sURL = sqlDataReader["URL"].ToString()
        //            });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    if (!flag1 && inventorySearch.iINVENTORYID != 0L)
        //    {
        //        inventorySearch.lstIMAGEURL = imageUrlList;
        //        inventorySearchList.Add(inventorySearch);
        //    }
        //    return inventorySearchList;
        //}

        //public List<Inventory> Filter(long iCATID, long iBRANDID, string sNEWUSED, string sPRICERANGE)
        //{
        //    Decimal dPriceStart;
        //    Decimal dPriceEnd;
        //    Method.SliderPrice(sPRICERANGE, out dPriceStart, out dPriceEnd);
        //    bool flag1 = false;
        //    List<Image> imageUrlList = new List<Image>();
        //    List<Inventory> inventorySearchList = new List<Inventory>();
        //    StringBuilder stringBuilder = new StringBuilder();
        //    bool bNEW;
        //    bool bUSED;
        //    Method.NEWUSED(sNEWUSED, out bNEW, out bUSED);
        //    Inventory inventorySearch = new Inventory();
        //    bool flag2 = false;
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INVENTORYFILTER", connection);
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt);
        //    sqlCommand.Parameters["@biCATID"].Value = (object)iCATID;
        //    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt);
        //    sqlCommand.Parameters["@biBRANDID"].Value = (object)iBRANDID;
        //    sqlCommand.Parameters.Add("@bNEW", SqlDbType.Bit);
        //    sqlCommand.Parameters["@bNEW"].Value = (object)bNEW;
        //    sqlCommand.Parameters.Add("@bUSED", SqlDbType.Bit);
        //    sqlCommand.Parameters["@bUSED"].Value = (object)bUSED;
        //    sqlCommand.Parameters.Add("@dPRICESTART", SqlDbType.Decimal);
        //    sqlCommand.Parameters["@dPRICESTART"].Value = (object)dPriceStart;
        //    sqlCommand.Parameters.Add("@dPRICEEND", SqlDbType.Decimal);
        //    sqlCommand.Parameters["@dPRICEEND"].Value = (object)dPriceEnd;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        while (sqlDataReader.Read())
        //        {
        //            if (!flag2)
        //            {
        //                stringBuilder.Append(sqlDataReader["INVENTORYID"].ToString());
        //                if (!(stringBuilder.ToString() == "0") && !(sqlDataReader["QUANTITY"].ToString() == "0"))
        //                {
        //                    inventorySearch.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
        //                    inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                    inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                    inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                    inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                    inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                    inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                    inventorySearch.iBRANDID = long.Parse(sqlDataReader["BRANDID"].ToString());
        //                    inventorySearch.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
        //                    inventorySearch.iCUSTID = long.Parse(sqlDataReader["CUSTID"].ToString());
        //                    inventorySearch.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
        //                    inventorySearch.iQUANTITY = long.Parse(sqlDataReader["QUANTITY"].ToString());
        //                    inventorySearch.bNEW = (bool)sqlDataReader["NEW"];
        //                    inventorySearch.bUSED = (bool)sqlDataReader["USED"];
        //                    inventorySearch.dPRICE = Decimal.Parse(sqlDataReader["PRICE"].ToString());
        //                    inventorySearch.iCATID = long.Parse(sqlDataReader["CATID"].ToString());
        //                    flag2 = true;
        //                }
        //                else
        //                    break;
        //            }
        //            if (stringBuilder.ToString() != sqlDataReader["INVENTORYID"].ToString())
        //            {
        //                inventorySearch.lstIMAGEURL = imageUrlList;
        //                inventorySearchList.Add(inventorySearch);
        //                stringBuilder.Clear();
        //                imageUrlList = new List<Image>();
        //                inventorySearch = new Inventory();
        //                stringBuilder.Append(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                inventorySearch.iBRANDID = long.Parse(sqlDataReader["BRANDID"].ToString());
        //                inventorySearch.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
        //                inventorySearch.iCUSTID = long.Parse(sqlDataReader["CUSTID"].ToString());
        //                inventorySearch.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
        //                inventorySearch.iQUANTITY = long.Parse(sqlDataReader["QUANTITY"].ToString());
        //                inventorySearch.bNEW = (bool)sqlDataReader["NEW"];
        //                inventorySearch.bUSED = (bool)sqlDataReader["USED"];
        //                inventorySearch.dPRICE = Decimal.Parse(sqlDataReader["PRICE"].ToString());
        //                inventorySearch.iCATID = long.Parse(sqlDataReader["CATID"].ToString());
        //                flag1 = true;
        //            }
        //            imageUrlList.Add(new Image()
        //            {
        //                iIMAGEID = long.Parse(sqlDataReader["IMAGEID"].ToString()),
        //                sURL = sqlDataReader["URL"].ToString()
        //            });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    if (!flag1 && inventorySearch.iINVENTORYID != 0L)
        //    {
        //        inventorySearch.lstIMAGEURL = imageUrlList;
        //        inventorySearchList.Add(inventorySearch);
        //    }
        //    return inventorySearchList;
        //}

        //public bool InventoryIDImage(long iINVENTORYID, ref ProductEntryModel clsProductEntryModel)
        //{
        //    bool flag = true;
        //    List<Image> imageUrlList = new List<Image>();
        //    List<Inventory> inventorySearchList = new List<Inventory>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_IMAGE", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                inventorySearchList.Add(new Inventory()
        //                {
        //                    sPRODUCT = sqlDataReader["PRODUCT"].ToString()
        //                });
        //        }
        //        if (sqlDataReader.NextResult() && sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                imageUrlList.Add(new Image()
        //                {
        //                    iIMAGEID = Method.ParseLong(sqlDataReader["IMAGEID"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString(),
        //                    bMAIN = bool.Parse(sqlDataReader["MAIN"].ToString()),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString())
        //                });
        //        }
        //        connection.Close();
        //        clsProductEntryModel.Inventory = inventorySearchList;
        //        clsProductEntryModel.ImageURL = imageUrlList;
        //    }
        //    catch (Exception ex)
        //    {
        //        flag = false;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return flag;
        //}

        //public List<Video> InventoryIDVideo(long iINVENTORYID)
        //{
        //    List<Video> videoList = new List<Video>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_VIDEO", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                videoList.Add(new Video()
        //                {
        //                    iVIDEOID = Method.ParseLong(sqlDataReader["VIDEOID"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString(),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString()),
        //                    bYOUTUBE = Method.ParseBool(sqlDataReader["YOUTUBE"].ToString())
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return videoList;
        //}

        //public List<Product> AutoCompleteProduct(string sPRODSEARCH, long iCATID, long iBRANDID, string sYEAR, long iCUSTID)
        //{
        //    List<Product> productList = new List<Product>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_PRODUCTAUTOCOMPLETE", connection);
        //    sqlCommand.Parameters.Add("@vPRODSEARCH", SqlDbType.VarChar).Value = (object)Method.WildCard(sPRODSEARCH);
        //    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = (object)iBRANDID;
        //    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = (object)iCATID;
        //    sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = (object)sYEAR;
        //    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = (object)iCUSTID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                productList.Add(new Product()
        //                {
        //                    sPRODUCT = sqlDataReader["year_prod"].ToString(),
        //                    iPRODID = Method.ParseLong(sqlDataReader["PRODID"].ToString())
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return productList;
        //}

        //public List<Video> UpdateVideo(long iINVENTORYID, long iVideoID, string sURL)
        //{
        //    List<Video> videoList = new List<Video>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_UPDATEVIDEO", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = (object)iVideoID;
        //    sqlCommand.Parameters.Add("@vURL", SqlDbType.VarChar).Value = (object)sURL;
        //    sqlCommand.Parameters.Add("@bYOUTUBE", SqlDbType.Bit).Value = (object)true;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                videoList.Add(new Video()
        //                {
        //                    iVIDEOID = Method.ParseLong(sqlDataReader["VIDEOID"].ToString()),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString()),
        //                    bYOUTUBE = Method.ParseBool(sqlDataReader["YOUTUBE"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return videoList;
        //}

        //public List<Video> DeleteVideo(long iINVENTORYID, long iVideoID)
        //{
        //    List<Video> videoList = new List<Video>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_DELETEVIDEO", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.Parameters.Add("@biVIDEOID", SqlDbType.BigInt).Value = (object)iVideoID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                videoList.Add(new Video()
        //                {
        //                    iVIDEOID = Method.ParseLong(sqlDataReader["VIDEOID"].ToString()),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString()),
        //                    bYOUTUBE = Method.ParseBool(sqlDataReader["YOUTUBE"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return videoList;
        //}

        //public List<Video> AddVideo(long iINVENTORYID, string sURL, bool bYouTube)
        //{
        //    List<Video> videoList = new List<Video>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INSERTVIDEO", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.Parameters.Add("@vURL", SqlDbType.VarChar).Value = (object)sURL;
        //    sqlCommand.Parameters.Add("@bYouTube", SqlDbType.Bit).Value = (object)bYouTube;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                videoList.Add(new Video()
        //                {
        //                    iVIDEOID = Method.ParseLong(sqlDataReader["VIDEOID"].ToString()),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString()),
        //                    bYOUTUBE = Method.ParseBool(sqlDataReader["YOUTUBE"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return videoList;
        //}

        //public List<RelateProductRelate> AddProductRelate(long iRELATEPRODID, long iINVENTORYID, long iCUSTID)
        //{
        //    List<RelateProductRelate> relateProductRelateList = new List<RelateProductRelate>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INSERTPRODUCTRELATE", connection);
        //    sqlCommand.Parameters.Add("@biRELATEPRODID", SqlDbType.BigInt).Value = (object)iRELATEPRODID;
        //    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = (object)iCUSTID;
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                relateProductRelateList.Add(new RelateProductRelate()
        //                {
        //                    iPRODRELATEID = Method.ParseLong(sqlDataReader["PRODRELATEID"].ToString()),
        //                    sRELATEPRODUCT = sqlDataReader["RELATEPRODUCT"].ToString(),
        //                    sRELATEDESCRIPTION = sqlDataReader["RELATEDESCRIPTION"].ToString(),
        //                    sRELATEYEAR = sqlDataReader["RELATEYEAR"].ToString(),
        //                    sRELATEURL = sqlDataReader["RELATEURL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return relateProductRelateList;
        //}

        //public List<RelateProductRelate> RemoveProductRelate(long iPRODRELATEID, long iCUSTID, long iINVENTORYID)
        //{
        //    List<RelateProductRelate> relateProductRelateList = new List<RelateProductRelate>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_DELETEPRODUCTRELATE", connection);
        //    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = (object)iCUSTID;
        //    sqlCommand.Parameters.Add("@biPRODRELATEID", SqlDbType.BigInt).Value = (object)iPRODRELATEID;
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    bool flag = false;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            flag = true;
        //            while (sqlDataReader.Read())
        //                relateProductRelateList.Add(new RelateProductRelate()
        //                {
        //                    iPRODRELATEID = Method.ParseLong(sqlDataReader["PRODRELATEID"].ToString()),
        //                    sRELATEPRODUCT = sqlDataReader["RELATEPRODUCT"].ToString(),
        //                    sRELATEDESCRIPTION = sqlDataReader["RELATEDESCRIPTION"].ToString(),
        //                    sRELATEYEAR = sqlDataReader["RELATEYEAR"].ToString(),
        //                    sRELATEURL = sqlDataReader["RELATEURL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        flag = false;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return relateProductRelateList;
        //}

        //public List<RelateProductRelate> ProductRelate(long iINVENTORYID, long iCUSTID)
        //{
        //    List<RelateProductRelate> relateProductRelateList = new List<RelateProductRelate>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_PRODUCTRELATE", connection);
        //    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = (object)iCUSTID;
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    bool flag = false;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            flag = true;
        //            while (sqlDataReader.Read())
        //                relateProductRelateList.Add(new RelateProductRelate()
        //                {
        //                    iPRODRELATEID = Method.ParseLong(sqlDataReader["PRODRELATEID"].ToString()),
        //                    sRELATEPRODUCT = sqlDataReader["RELATEPRODUCT"].ToString(),
        //                    sRELATEDESCRIPTION = sqlDataReader["RELATEDESCRIPTION"].ToString(),
        //                    sRELATEYEAR = sqlDataReader["RELATEYEAR"].ToString(),
        //                    sRELATEURL = sqlDataReader["RELATEURL"].ToString()
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        flag = false;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return relateProductRelateList;
        //}

        public bool DisplayProduct(bool bDisplay, long iINVENTORYID)
        {
            bool flag = true;
            SqlConnection connection = new SqlConnection(this.sCon);
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SP_DISPLAYPRODUCT", connection);
                sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
                sqlCommand.Parameters.Add("@bDisplay", SqlDbType.Bit).Value = (object)bDisplay;
                sqlCommand.CommandType = CommandType.StoredProcedure;
                connection.Open();
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                flag = false;
            }
            finally
            {
                connection.Close();
            }
            return flag;
        }

        //public List<Inventory> ProductRelateResult(long iCATID, long iBRANDID, long iPRODID, string sYEAR, long iCUSTID)
        //{
        //    List<Inventory> inventorySearchList = new List<Inventory>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_PRODUCTRELATERESULT", connection);
        //    sqlCommand.Parameters.Add("@biCATID", SqlDbType.BigInt).Value = (object)iCATID;
        //    sqlCommand.Parameters.Add("@biBRANDID", SqlDbType.BigInt).Value = (object)iBRANDID;
        //    sqlCommand.Parameters.Add("@biPRODID", SqlDbType.BigInt).Value = (object)iPRODID;
        //    sqlCommand.Parameters.Add("@vYEAR", SqlDbType.VarChar).Value = (object)sYEAR;
        //    sqlCommand.Parameters.Add("@biCUSTID", SqlDbType.BigInt).Value = (object)iCUSTID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //            {
        //                Inventory inventorySearch = new Inventory();
        //                List<Image> imageUrlList = new List<Image>();
        //                Image imageUrl = new Image();
        //                inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                inventorySearch.iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.iPRODID = Method.ParseLong(sqlDataReader["PRODID"].ToString());
        //                imageUrl.sURL = sqlDataReader["URL"].ToString();
        //                inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                inventorySearch.dPRICE = Method.ParseDecimal(sqlDataReader["PRICE"].ToString());
        //                inventorySearch.bNEW = Method.ParseBool(sqlDataReader["NEW"].ToString());
        //                inventorySearch.bUSED = Method.ParseBool(sqlDataReader["USED"].ToString());
        //                inventorySearch.iQUANTITY = Method.ParseLong(sqlDataReader["QUANTITY"].ToString());
        //                inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                imageUrlList.Add(imageUrl);
        //                inventorySearch.lstIMAGEURL = imageUrlList;
        //                inventorySearchList.Add(inventorySearch);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return inventorySearchList;
        //}

        //public List<Image> DeleteImage(long iINVENTORYID, string sURL)
        //{
        //    List<Image> imageUrlList = new List<Image>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_DELETEIMAGE", connection);
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.Parameters.Add("@vURL", SqlDbType.VarChar).Value = (object)sURL;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                imageUrlList.Add(new Image()
        //                {
        //                    iIMAGEID = long.Parse(sqlDataReader["IMAGEID"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString(),
        //                    bMAIN = bool.Parse(sqlDataReader["MAIN"].ToString()),
        //                    iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString())
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return imageUrlList;
        //}

        public bool FlagMainImage(long iINVENTORYID, long iIMAGEID)
        {
            bool flag = true;
            List<Image> imageUrlList = new List<Image>();
            SqlConnection connection = new SqlConnection(this.sCon);
            SqlCommand sqlCommand = new SqlCommand("SP_MAINIMAGEID", connection);
            sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
            sqlCommand.Parameters.Add("@biIMAGEID", SqlDbType.BigInt).Value = (object)iIMAGEID;
            sqlCommand.CommandType = CommandType.StoredProcedure;
            try
            {
                connection.Open();
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                flag = false;
            }
            finally
            {
                connection.Close();
            }
            return flag;
        }

        //public List<Image> ImageUpload(string sURL, string sFILEEXTENSION, long iINVENTORYID)
        //{
        //    List<Image> imageUrlList = new List<Image>();
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INSERTIMAGE", connection);
        //    sqlCommand.Parameters.Add("@vURL", SqlDbType.VarChar).Value = (object)sURL;
        //    sqlCommand.Parameters.Add("@vFILEEXTENSION", SqlDbType.VarChar).Value = (object)sFILEEXTENSION;
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt).Value = (object)iINVENTORYID;
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        if (sqlDataReader.HasRows)
        //        {
        //            while (sqlDataReader.Read())
        //                imageUrlList.Add(new Image()
        //                {
        //                    iIMAGEID = Method.ParseLong(sqlDataReader["IMAGEID"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString(),
        //                    sFILENAME = sqlDataReader["FILENAME"].ToString(),
        //                    bMAIN = Method.ParseBool(sqlDataReader["MAIN"].ToString()),
        //                    iINVENTORYID = Method.ParseLong(sqlDataReader["INVENTORYID"].ToString())
        //                });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return imageUrlList;
        //}



        //public List<Inventory> SearchProdDetail(long iINVENTORYID)
        //{
        //    List<Image> imageUrlList = new List<Image>();
        //    List<Inventory> inventorySearchList = new List<Inventory>();
        //    StringBuilder stringBuilder = new StringBuilder();
        //    Inventory inventorySearch = new Inventory();
        //    bool flag = false;
        //    SqlConnection connection = new SqlConnection(this.sCon);
        //    SqlCommand sqlCommand = new SqlCommand("SP_INVENTORYIDSEARCH", connection);
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    sqlCommand.Parameters.Add("@biINVENTORYID", SqlDbType.BigInt);
        //    sqlCommand.Parameters["@biINVENTORYID"].Value = (object)iINVENTORYID;
        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        while (sqlDataReader.Read())
        //        {
        //            if (!flag)
        //            {
        //                stringBuilder.Append(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.iINVENTORYID = long.Parse(sqlDataReader["INVENTORYID"].ToString());
        //                inventorySearch.sPRODUCT = sqlDataReader["PRODUCT"].ToString();
        //                inventorySearch.sDESCRIPTION = sqlDataReader["DESCRIPTION"].ToString();
        //                inventorySearch.sSIZE = sqlDataReader["SIZE"].ToString();
        //                inventorySearch.sCOLOR = sqlDataReader["COLOR"].ToString();
        //                inventorySearch.sDISPLAYNAME = sqlDataReader["DISPLAYNAME"].ToString();
        //                inventorySearch.sYEAR = sqlDataReader["YEAR"].ToString();
        //                inventorySearch.iBRANDID = long.Parse(sqlDataReader["BRANDID"].ToString());
        //                inventorySearch.iPRODID = long.Parse(sqlDataReader["PRODID"].ToString());
        //                inventorySearch.iCUSTID = long.Parse(sqlDataReader["CUSTID"].ToString());
        //                inventorySearch.iSIZEID = long.Parse(sqlDataReader["SIZEID"].ToString());
        //                inventorySearch.iQUANTITY = long.Parse(sqlDataReader["QUANTITY"].ToString());
        //                inventorySearch.bNEW = (bool)sqlDataReader["NEW"];
        //                inventorySearch.bUSED = (bool)sqlDataReader["USED"];
        //                inventorySearch.dPRICE = Decimal.Parse(sqlDataReader["PRICE"].ToString());
        //                inventorySearch.iCATID = long.Parse(sqlDataReader["CATID"].ToString());
        //                flag = true;
        //            }
        //            if (string.Concat(sqlDataReader["IMAGEID"]) != "")
        //                imageUrlList.Add(new Image()
        //                {
        //                    iIMAGEID = long.Parse(sqlDataReader["IMAGEID"].ToString()),
        //                    sURL = sqlDataReader["URL"].ToString()
        //                });
        //        }
        //        inventorySearch.lstIMAGEURL = imageUrlList;
        //        inventorySearchList.Add(inventorySearch);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return inventorySearchList;
        //}
        
    }
}
