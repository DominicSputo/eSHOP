﻿using System;
using System.Collections.Generic;

namespace eSHOP.Models
{
    public class Inventory
    {
        public long iINVENTORYID { get; set; }
        public long iBRANDID { get; set; }
        public long iCATID { get; set; }
        public string sPRODUCTNAME { get; set; }
        public string sDESCRIPTION { get; set; }
        public string sYEAR { get; set; }
        public string sCOLOR { get; set; }
        public string sSIZE { get; set; }
        public long iLOGONID { get; set; }
        public long iQUANTITY { get; set; }
        public bool bNEW { get; set; }
        public bool bUSED { get; set; }
        public Decimal dPRICE { get; set; }
        public Guid guINVENTORYGUIDID { get; set; }
        public bool bRECOMMENDITEM { get; set; }
        public List<Image> lstIMAGEURL { get; set; }
    }
}