﻿using System.Collections.Generic;

namespace eSHOP.Models
{
    public class CategoryBrand
    {
        public List<Category> lstCategory { get; set; }

        public List<Brand> lstBrand { get; set; }
    }
}