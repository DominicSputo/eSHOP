﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eSHOP.Models;
using System.Threading.Tasks;
namespace eSHOP.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            SQLData cSQLData = new SQLData();
            CategoryInventorySearch cCIS = new CategoryInventorySearch();
            cSQLData.LoadCategoryInventorySearch(ref cCIS, "", "", "", "", "", 10, 1);
            cCIS.CategoryBrand = new CategoryBrand() { lstBrand = cSQLData.SP_BRANDCOUNT(), lstCategory = cSQLData.SP_CATEGORY_BRAND() };
            return (ActionResult)View(cCIS);
        }
                
        public ActionResult GetImage(string sIMAGEGUIDID)
        {
            byte[] bytIMAGE = new byte[0];
            SQLData cSQLData = new SQLData();
            cSQLData.LoadIMAGE(Guid.Parse(Method.URLDecode(sIMAGEGUIDID)), ref bytIMAGE);
            return File(bytIMAGE, "image/jpeg");
        }

        [HttpPost]
        public JsonResult ERRORLOGGING(string error, string page, string function)
        {
            SQLData.Error(false, true, page, function, "CSHTML PAGE : \"" + page + "\" FUNCTION : \"" + function + "\" ERROR: \"" + error + "\"", "");
            //new eCommerceDBContext().SP_INSERTERROR(new bool?(false), new bool?(true), new bool?(false), "CSHTML PAGE : \"" + page + "\" FUNCTION : \"" + function + "\" ERROR: \"" + error + "\"");
            return this.Json((object)null, JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult FilterProduct(string NEWUSED, string SLD, string BRAND, string CATEGORYBRAND, string SORT, string NUMBERPERPAGE, string PAGENUMBER)
        {        
            SQLData cSQLData = new SQLData();
            CategoryInventorySearch cCIS = new CategoryInventorySearch();
            Method.DefaultNullFilterSearchParam(ref PAGENUMBER, ref SORT, ref NUMBERPERPAGE);
            cSQLData.LoadCategoryInventorySearch(ref cCIS, "", CATEGORYBRAND, BRAND, NEWUSED, SLD, int.Parse(NUMBERPERPAGE), int.Parse(PAGENUMBER), SORT);
             return (ActionResult)PartialView("FilterFeature", cCIS);
        }



        //public async Task<ActionResult> RenderImage(string sIMAGEGUIDID)
        //{
        //    eShopDBContext context = new eShopDBContext();

        //    Item item = await context.SP_IMAGEGUIDID.IMAGEs.FindAsync(id);

        //    byte[] photoBack = item.InternalImage;

        //    return File(photoBack, "image/png");
        //}



        //public async Task<ActionResult> RenderImage(byte[] bytIMAGE)
        //{
        //    return File(bytIMAGE, "image/jpeg");
        //}

        //Session["CUSTID"] = (object)1000001;
        //CategoryInventorySearch inventorySearchModel = new CategoryInventorySearch();
        //CategoryBrand categoryBrandModel = new CategoryBrand();
        //SQLData sqlData = new SQLData();
        //LinqData linqData = new LinqData();
        //List<VU_INVENTORY> lstINVENTORY = linqData.LoadInventoryTop6();
        //inventorySearchModel.Inventory = linqData.LoadInventorySearch(ref lstINVENTORY);
        //categoryBrandModel.Category = sqlData.CategoryBrandList();
        //categoryBrandModel.Brand = sqlData.BrandList();
        //inventorySearchModel.CategoryBrand = categoryBrandModel;
        //inventorySearchModel.Pager = new Pager()
        //{
        //    iCurrentPageNumber = 0,
        //    iNumberProductPerPage = 0,
        //    iSearchResultCount = 0,
        //    iPageButtonCount = 0
        //};
        //eCommerceDBContext context = new eCommerceDBContext();
        ////CartDBContext cartDbContext = new CartDBContext();
        //inventorySearchModel.Cart = context.SP_CUSTCART(new long?(long.Parse(this.Session["CUSTID"].ToString()))).ToList<SP_CUSTCART_Result>();
        //return (ActionResult)this.View((object)inventorySearchModel);

        //public ActionResult About()
        //{
        //    return (ActionResult)this.View();
        //}

        //public ActionResult Contact()
        //{
        //    return (ActionResult)this.View();
        //}

        //public ActionResult Cart()
        //{
        //    return (ActionResult)this.View((object)new eCommerceDBContext());
        //}

        //[HttpPost]
        //public JsonResult DeleteCartItem(string ID)
        //{
        //    long iValue;
        //    Method.AssignLongVal(ID, out iValue);
        //    return this.Json((object)new eCommerceDBContext().SP_DELETECARTITEM(new long?(long.Parse(this.Session["CUSTID"].ToString())), new long?(iValue)).ToList<SP_DELETECARTITEM_Result>(), JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public JsonResult ERRORLOGGING(string error, string page, string function)
        //{
        //    new eCommerceDBContext().SP_INSERTERROR(new bool?(false), new bool?(true), new bool?(false), "CSHTML PAGE : \"" + page + "\" FUNCTION : \"" + function + "\" ERROR: \"" + error + "\"");
        //    return this.Json((object)null, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public JsonResult UpdatePopCart(string ID, string Q)
        //{
        //    long num = long.Parse(this.Session["CUSTID"].ToString());
        //    long iValue1;
        //    Method.AssignLongVal(ID, out iValue1);
        //    long iValue2;
        //    Method.AssignLongVal(Q, out iValue2);
        //    return this.Json((object)new eCommerceDBContext().SP_UPDATECART(new long?(num), new long?(iValue2), new long?(iValue1)).ToList<SP_UPDATECART_Result>(), JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public JsonResult UpdateCartQuantity(SP_CUSTCART_Result obj)
        //{
        //    return this.Json((object)new eCommerceDBContext().SP_UPDATECART(new long?(long.Parse(this.Session["CUSTID"].ToString())), obj.quantity, obj.inventoryid).ToList<SP_UPDATECART_Result>(), JsonRequestBehavior.AllowGet);
        //}

        //public ActionResult Checkout()
        //{
        //    return (ActionResult)this.View();
        //}

        //public ActionResult Search(string CAT, string BID, string CND, string SLD)
        //{
        //    CategoryInventorySearchModel inventorySearchModel = new CategoryInventorySearchModel();
        //    CategoryBrandModel categoryBrandModel = new CategoryBrandModel();
        //    SQLData sqlData = new SQLData();
        //    long result1;
        //    long result2;
        //    if (long.TryParse(BID, out result1) && long.TryParse(CAT, out result2))
        //    {
        //        inventorySearchModel.Inventory = sqlData.Search(result2, result1, CND, SLD);
        //        categoryBrandModel.Category = sqlData.CategoryBrandList();
        //        categoryBrandModel.Brand = sqlData.BrandList();
        //        inventorySearchModel.CategoryBrand = categoryBrandModel;
        //    }
        //    else if (long.TryParse(BID, out result1) && CAT == null)
        //    {
        //        long iCATID = 0;
        //        inventorySearchModel.Inventory = sqlData.Search(iCATID, result1, CND, SLD);
        //        categoryBrandModel.Category = sqlData.CategoryBrandList();
        //        categoryBrandModel.Brand = sqlData.BrandList();
        //        inventorySearchModel.CategoryBrand = categoryBrandModel;
        //    }
        //    return (ActionResult)this.View((object)inventorySearchModel);
        //}

        //public ActionResult ProductDetail(string INV)
        //{
        //    CategoryInventorySearchModel inventorySearchModel = new CategoryInventorySearchModel();
        //    CategoryBrandModel categoryBrandModel = new CategoryBrandModel();
        //    SQLData sqlData = new SQLData();
        //    long result;
        //    if (long.TryParse(INV, out result))
        //    {
        //        inventorySearchModel.Inventory = sqlData.SearchProdDetail(result);
        //        categoryBrandModel.Category = sqlData.CategoryBrandList();
        //        categoryBrandModel.Brand = sqlData.BrandList();
        //        inventorySearchModel.CategoryBrand = categoryBrandModel;
        //        eCommerceDBContext cartDbContext = new eCommerceDBContext();
        //        inventorySearchModel.Cart = cartDbContext.SP_CUSTCART(new long?(long.Parse(this.Session["CUSTID"].ToString()))).ToList<SP_CUSTCART_Result>();
        //        inventorySearchModel.Video = cartDbContext.SP_VIDEO(new long?(result)).ToList<SP_VIDEO_Result>();
        //    }
        //    return (ActionResult)this.View((object)inventorySearchModel);
        //}

        //[HttpPost]
        //public JsonResult AddCartItem(string c, string q)
        //{
        //    return this.Json((object)new eCommerceDBContext().SP_INSERTCUSTCART(new long?(long.Parse(this.Session["CUSTID"].ToString())), new long?(long.Parse(c)), new long?(long.Parse(q))), JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public ActionResult RefreshPopCart()
        //{
        //    CategoryInventorySearchModel inventorySearchModel = new CategoryInventorySearchModel();
        //    eCommerceDBContext cartDbContext = new eCommerceDBContext();
        //    inventorySearchModel.Cart = cartDbContext.SP_CUSTCART(new long?(long.Parse(this.Session["CUSTID"].ToString()))).ToList<SP_CUSTCART_Result>();
        //    return (ActionResult)this.PartialView("_PopoutCart", (object)inventorySearchModel);
        //}

        //[HttpPost]
        //public ActionResult LoadProductDetail(string IID)
        //{
        //    CategoryInventorySearchModel inventorySearchModel = new CategoryInventorySearchModel();
        //    SQLData sqlData = new SQLData();
        //    long result;
        //    if (long.TryParse(IID, out result))
        //    {
        //        inventorySearchModel.Inventory = sqlData.SearchProdDetail(result);
        //        eCommerceDBContext cartDbContext = new eCommerceDBContext();
        //        inventorySearchModel.Video = cartDbContext.SP_VIDEO(new long?(result)).ToList<SP_VIDEO_Result>();
        //        inventorySearchModel.Cart = cartDbContext.SP_CUSTCART(new long?(long.Parse(this.Session["CUSTID"].ToString()))).ToList<SP_CUSTCART_Result>();
        //    }
        //    return (ActionResult)this.PartialView("_ProductDetail", (object)inventorySearchModel);
        //}

        //[HttpPost]
        //public ActionResult FilterProduct(string CND, string SLD, string BRAND, string CATEGORYBRAND, string SORT, string NUMBERPERPAGE, string PAGENUMBER)
        //{
        //    Method.DefaultNullFilterSearchParam(ref PAGENUMBER, ref SORT, ref NUMBERPERPAGE);
        //    Decimal dPriceStart;
        //    Decimal dPriceEnd;
        //    Method.SliderPrice(SLD, out dPriceStart, out dPriceEnd);
        //    bool bNEW;
        //    bool bUSED;
        //    Method.NEWUSED(CND, out bNEW, out bUSED);
        //    IEnumerable<long> iBRAND;
        //    Method.LoadBrandSplit(BRAND, out iBRAND);
        //    int iValue1;
        //    Method.AssignIntVal(NUMBERPERPAGE, out iValue1);
        //    int iValue2;
        //    Method.AssignIntVal(PAGENUMBER, out iValue2);
        //    LinqData linqData = new LinqData();
        //    SQLData sqlData = new SQLData();
        //    eCommerceDBContext cartDbContext = new eCommerceDBContext();
        //    List<VU_INVENTORY> vuInventoryList = new List<VU_INVENTORY>();
        //    CategoryInventorySearchModel inventorySearchModel = new CategoryInventorySearchModel();
        //    CategoryBrandModel categoryBrandModel = new CategoryBrandModel();
        //    List<CategoryBrandSplit> source1 = Method.LoadCategoryBrandSplit(CATEGORYBRAND);
        //    int num = Method.CountInt64Array(ref iBRAND);
        //    if (source1.Count<CategoryBrandSplit>() > 0 && num == 0)
        //    {
        //        foreach (IEnumerable<CategoryBrandSplit> categoryBrandSplits in source1.GroupBy<CategoryBrandSplit, long>((Func<CategoryBrandSplit, long>)(catbrand => catbrand.iCATID)).Select<IGrouping<long, CategoryBrandSplit>, IGrouping<long, CategoryBrandSplit>>((Func<IGrouping<long, CategoryBrandSplit>, IGrouping<long, CategoryBrandSplit>>)(catbrandgroup => catbrandgroup)))
        //        {
        //            using (IEnumerator<CategoryBrandSplit> enumerator = categoryBrandSplits.GetEnumerator())
        //            {
        //                while (enumerator.MoveNext())
        //                {
        //                    CategoryBrandSplit iCATIDBRANDID = enumerator.Current;
        //                    vuInventoryList = vuInventoryList.Concat<VU_INVENTORY>((IEnumerable<VU_INVENTORY>)cartDbContext.VU_INVENTORY.Where<VU_INVENTORY>((Expression<Func<VU_INVENTORY, bool>>)(inventory => inventory.catid == iCATIDBRANDID.iCATID && inventory.brandid == iCATIDBRANDID.iBRANDID && (inventory.price >= dPriceStart && inventory.price <= dPriceEnd) && (inventory.@new == bNEW || inventory.used == bUSED)))).ToList<VU_INVENTORY>();
        //                }
        //            }
        //        }
        //    }
        //    else if (source1.Count<CategoryBrandSplit>() == 0 && num > 0)
        //        vuInventoryList = cartDbContext.VU_INVENTORY.Where<VU_INVENTORY>((Expression<Func<VU_INVENTORY, bool>>)(inventory => iBRAND.Contains<long>(inventory.brandid) && (inventory.price >= dPriceStart && inventory.price <= dPriceEnd) && (inventory.@new == bNEW || inventory.used == bUSED))).ToList<VU_INVENTORY>();
        //    else if (source1.Count<CategoryBrandSplit>() > 0 && num > 0)
        //    {
        //        foreach (IEnumerable<CategoryBrandSplit> categoryBrandSplits in source1.GroupBy<CategoryBrandSplit, long>((Func<CategoryBrandSplit, long>)(catbrand => catbrand.iCATID)).Select<IGrouping<long, CategoryBrandSplit>, IGrouping<long, CategoryBrandSplit>>((Func<IGrouping<long, CategoryBrandSplit>, IGrouping<long, CategoryBrandSplit>>)(catbrandgroup => catbrandgroup)))
        //        {
        //            using (IEnumerator<CategoryBrandSplit> enumerator = categoryBrandSplits.GetEnumerator())
        //            {
        //                while (enumerator.MoveNext())
        //                {
        //                    CategoryBrandSplit iCATIDBRANDID = enumerator.Current;
        //                    vuInventoryList = vuInventoryList.Concat<VU_INVENTORY>((IEnumerable<VU_INVENTORY>)cartDbContext.VU_INVENTORY.Where<VU_INVENTORY>((Expression<Func<VU_INVENTORY, bool>>)(inventory => (iBRAND.Contains<long>(inventory.brandid) || inventory.catid == iCATIDBRANDID.iCATID && inventory.brandid == iCATIDBRANDID.iBRANDID) && (inventory.price >= dPriceStart && inventory.price <= dPriceEnd) && (inventory.@new == bNEW || inventory.used == bUSED)))).ToList<VU_INVENTORY>();
        //                }
        //            }
        //        }
        //    }
        //    else
        //        vuInventoryList = linqData.LoadInventoryTop6();
        //    List<VU_INVENTORY> list1 = vuInventoryList.OrderBy<VU_INVENTORY, string>((Func<VU_INVENTORY, string>)(inv => inv.product)).ThenBy<VU_INVENTORY, long>((Func<VU_INVENTORY, long>)(inv => inv.inventoryid)).ToList<VU_INVENTORY>();
        //    List<InventorySearch> source2 = linqData.LoadInventorySearch(ref list1);
        //    List<InventorySearch> list2;
        //    switch (SORT)
        //    {
        //        case "LowToHigh":
        //            list2 = source2.OrderBy<InventorySearch, Decimal>((Func<InventorySearch, Decimal>)(inv => inv.dPRICE)).ThenBy<InventorySearch, string>((Func<InventorySearch, string>)(inv => inv.sPRODUCT)).ToList<InventorySearch>();
        //            break;
        //        case "HighToLow":
        //            list2 = source2.OrderByDescending<InventorySearch, Decimal>((Func<InventorySearch, Decimal>)(inv => inv.dPRICE)).ThenBy<InventorySearch, string>((Func<InventorySearch, string>)(inv => inv.sPRODUCT)).ToList<InventorySearch>();
        //            break;
        //        case "Product":
        //            list2 = source2.OrderBy<InventorySearch, string>((Func<InventorySearch, string>)(inv => inv.sPRODUCT)).ToList<InventorySearch>();
        //            break;
        //        default:
        //            list2 = source2.OrderBy<InventorySearch, string>((Func<InventorySearch, string>)(inv => inv.sYEAR)).ThenBy<InventorySearch, string>((Func<InventorySearch, string>)(inv => inv.sPRODUCT)).ToList<InventorySearch>();
        //            break;
        //    }
        //    Pager pager = new Pager();
        //    pager.iCurrentPageNumber = iValue2;
        //    pager.iNumberProductPerPage = iValue1;
        //    pager.iSearchResultCount = list2.Count<InventorySearch>();
        //    pager.iPageButtonCount = Method.PageButtonCount(pager.iSearchResultCount, iValue1);
        //    pager.sSortOrder = SORT;
        //    inventorySearchModel.Pager = pager;
        //    List<InventorySearch> list3 = list2.Skip<InventorySearch>(iValue1 * (iValue2 - 1)).Take<InventorySearch>(iValue1).ToList<InventorySearch>();
        //    inventorySearchModel.Inventory = list3;
        //    return (ActionResult)this.PartialView("_FilterSearch", (object)inventorySearchModel);
        //}

        //[HttpPost]
        //public ActionResult Advertise()
        //{
        //    return (ActionResult)this.PartialView("_Advertisement");
        //}
    }
}