﻿function LogError(errmsg, page, ajaxfunc) {
    $.ajax({
        type: "POST",
        url: "/HOME/ERRORLOGGING",
        data: { "error": errmsg, "page": page, "function": ajaxfunc }
    }).done(function (data) {
        //generate("warning", ' <b>' + data + '</b>x "<b><u>' + $('#hProd').html() + '</u></b>" added to Cart', 'fa fa-cog fa-spin fa-2x');
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
        //generate("error ", 'ERROR - ' + errorThrown + " textStatus " + textStatus + " jqXHR " + jqXHR, 'fa fa-cog fa-spin fa-2x');
    });
}

function Encode(sV) {
    return encodeURIComponent(sV);
}